# TraceConnect — Alpha Prototype

A 3-tier Streamlit application wrapping the existing `ocr_pipeline.py`
engine. This is a validation/data-collection instrument — deliberately
disposable — not the Rev02 production architecture. See
`ENGINEERING_WIKI.md` for the full technical breakdown of every pattern
used here.

## Repository layout

```
traceconnect_app/
├── app.py                 # FRONTEND — Streamlit UI, session_state, CSS. No OCR, no disk I/O.
├── engine_bridge.py        # MIDDLEWARE — Pydantic contracts, async dispatch, error containment.
├── data_vault.py            # BACKEND — wraps ocr_pipeline.run_pipeline(), atomic storage, retries.
├── ocr_pipeline.py           # Your existing OCR engine — untouched, imported not modified.
├── requirements.txt
├── ENGINEERING_WIKI.md        # Internal engineering education doc
├── README.md                   # This file
├── .streamlit/
│   └── config.toml               # Theme config
│
# Created automatically at runtime (not checked into git — see .gitignore below):
├── ocr_storage.json              # [required by spec] append-only OCR execution log
├── ocr_corrections.json           # Human-correction log — the flywheel's actual fuel
├── ocr_storage.lock                # FileLock artifact, safe to delete when app isn't running
├── uploads/                         # Saved copies of uploaded files
└── ocr_outputs/                      # ocr_pipeline.py's own outputs (registry, perf log, per-doc JSON)
```

Suggested `.gitignore` additions:
```
ocr_storage.json
ocr_corrections.json
ocr_storage.lock
uploads/
ocr_outputs/
__pycache__/
```

## Run it locally — 5 steps

**1. Install dependencies**
```bash
pip install -r requirements.txt
```

**2. Install the Tesseract system binary + Malay language pack** (not pip-installable)
```bash
# Debian/Ubuntu
sudo apt-get install tesseract-ocr tesseract-ocr-msa

# macOS
brew install tesseract tesseract-lang
```

**3. Verify the OCR engine works standalone first** (isolates engine bugs from app bugs)
```bash
python3 ocr_pipeline.py --file test_docs/some_document.pdf
```

**4. Launch the app**
```bash
streamlit run app.py
```

**5. Open the URL Streamlit prints** (typically `http://localhost:8501`), upload a document, and process it.

That's the single command from the spec — step 4 — once steps 1–3 are done
once on a machine.

## Scaling the storage layer

The whole point of the `data_vault.py` boundary is that this migration
touches **one file**. Nothing in `app.py` or `engine_bridge.py` needs to
change.

| Stage | Trigger | What changes |
|---|---|---|
| **Now** | 2 founders, alpha testers | `ocr_storage.json` / `ocr_corrections.json`, file-locked, atomic-write JSON |
| **First Pilot** (100–500 docs, per your own Master Reference flywheel phases) | Multiple concurrent testers, need queryable history | Swap `_atomic_append()`'s body for `INSERT INTO ocr_events (...)` against a **Supabase free-tier Postgres** instance. Same function signature, same callers — `execute_ocr()` and `log_correction()` don't change their contracts. |
| **Scale** (500–5,000 docs) | Real concurrent load, need proper schema/migrations | Formalize into the Rev02 target: Postgres with real migrations (Organisation/Project/Document/Revision tables), S3-compatible object storage for the original files (replacing local `uploads/`), and this whole app becomes the frontend calling a real FastAPI backend instead of calling `data_vault.py` in-process. |

**Why Postgres and not "any SQL database" for the pilot step:** Rev02
already names PostgreSQL as the target production database. Choosing it now,
even at tiny scale, means the pilot-stage migration is a genuine small step
toward the real thing — not a second throwaway choice you'll replace twice.

**What does NOT need to change when you migrate:** `app.py` calls
`engine_bridge.dispatch_ocr()`, which calls `data_vault.execute_ocr()`. As
long as `execute_ocr()`'s return shape stays the same, the entire frontend
and middleware are unaware storage moved from a JSON file to a database.
That's Separation of Concerns paying for itself — see §1 of the wiki.
