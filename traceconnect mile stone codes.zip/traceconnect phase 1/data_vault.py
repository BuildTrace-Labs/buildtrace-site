"""
data_vault.py — BACKEND / CORE DATA & COMPUTE LAYER
=====================================================
This is the only file in the stack allowed to:
  1. Call the real OCR engine (ocr_pipeline.run_pipeline)
  2. Touch the filesystem for persistent storage
  3. Own the definition of what "successful" and "atomic" mean

Nothing above this layer (engine_bridge.py, app.py) should ever open
ocr_storage.json directly. They ask this module for data; this module
decides how it's stored. That boundary is the whole point — it's what
lets us swap ocr_storage.json for Postgres later without touching the
UI or the middleware at all.

WHY THIS FILE EXISTS SEPARATELY FROM ocr_pipeline.py:
ocr_pipeline.py is your OCR *engine* — it doesn't know or care that a
web app exists. data_vault.py is the *application* layer that adapts
the engine's output into what a running app needs: session tracking,
retry-safe execution, and durable storage. Keeping the engine ignorant
of the app is what let us test the engine standalone from the CLI
before any of this app code existed — and it's what will let a future
FastAPI backend reuse the exact same engine untouched.
"""

from __future__ import annotations

import json
import time
import uuid
import shutil
import logging
import tempfile
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

from filelock import FileLock, Timeout

import ocr_pipeline  # your existing, untouched OCR engine

log = logging.getLogger("data_vault")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)-8s %(message)s")

# ──────────────────────────────────────────────────────────────────────────
# Storage locations
# ──────────────────────────────────────────────────────────────────────────
BASE_DIR      = Path(__file__).parent
STORAGE_FILE  = BASE_DIR / "ocr_storage.json"          # required by spec: append-only OCR execution log
CORRECTIONS_FILE = BASE_DIR / "ocr_corrections.json"    # extension: human-correction log (flywheel fuel)
LOCK_FILE     = BASE_DIR / "ocr_storage.lock"
UPLOAD_DIR    = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

LOCK_TIMEOUT_S = 10          # how long a writer waits for the lock before giving up
MAX_RETRIES    = 3           # transient-failure retry budget for the OCR call itself
RETRY_BACKOFF_S = 1.5        # base delay between retries (exponential)


# ──────────────────────────────────────────────────────────────────────────
# Atomic append-only JSON log
# ──────────────────────────────────────────────────────────────────────────
#
# THE PROBLEM THIS SOLVES:
# Two users hit "Process" at nearly the same instant. Both read
# ocr_storage.json, both append their record in memory, both write the
# file back. Whichever write finishes last WINS — the other user's
# record is silently gone. This is a classic lost-update race condition.
#
# THE FIX, IN TWO PARTS:
#   1. FileLock — a cross-process advisory lock (a small .lock file on
#      disk). Only one process can hold it at a time; everyone else
#      blocks until it's free. This serializes ALL writers, whether
#      they're different Streamlit sessions, different threads, or even
#      different OS processes.
#   2. Write-to-temp-then-replace — we never write ocr_storage.json in
#      place. We write a full temp file, then use os.replace() (via
#      Path.replace), which on POSIX and modern Windows is an ATOMIC
#      filesystem rename. There is no instant in time where the file is
#      half-written; a reader either sees the old complete file or the
#      new complete file, never a corrupt partial one — even if the
#      process is killed mid-write.
#
def _read_json_log(path: Path) -> list:
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        log.error(f"Corrupt log file {path.name}, starting fresh in memory (file untouched): {e}")
        return []


def _atomic_append(path: Path, record: dict) -> bool:
    """Lock -> read -> append -> write-to-temp -> atomic rename -> unlock."""
    lock = FileLock(str(LOCK_FILE), timeout=LOCK_TIMEOUT_S)
    try:
        with lock:
            records = _read_json_log(path)
            records.append(record)
            fd, tmp_path = tempfile.mkstemp(dir=str(BASE_DIR), suffix=".tmp")
            try:
                with open(fd, "w", encoding="utf-8") as f:
                    json.dump(records, f, indent=2, ensure_ascii=False)
                Path(tmp_path).replace(path)   # atomic on POSIX + modern Windows
            except Exception:
                Path(tmp_path).unlink(missing_ok=True)
                raise
        return True
    except Timeout:
        log.error(f"Could not acquire lock within {LOCK_TIMEOUT_S}s — write DROPPED for {path.name}")
        return False


# ──────────────────────────────────────────────────────────────────────────
# Fault-tolerant OCR execution
# ──────────────────────────────────────────────────────────────────────────
#
# WHY RETRIES LIVE HERE AND NOT IN THE ENGINE OR THE UI:
# ocr_pipeline.py already has its own internal 3-stage fallback
# (MarkItDown -> Docling -> Tesseract) for QUALITY reasons — different
# extraction methods for different document conditions. That's a
# different concern from what we're doing here: retrying the SAME
# call after a TRANSIENT failure (a flaky Docling model download, a
# momentary disk hiccup). We learned this isn't hypothetical — in
# testing, Docling's layout model download over the network failed
# with a 403 in a restricted environment and the pipeline correctly
# fell through to Tesseract. A retry wrapper here protects against the
# narrower case of the whole call throwing before it gets that far.
def _execute_with_retry(file_path: Path, source_origin: str) -> dict:
    last_error: Optional[Exception] = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            result = ocr_pipeline.run_pipeline(file_path, compare_mode=False,
                                                source_origin=source_origin)
            if "error" in result:
                # Not transient (bad file type, missing file) — don't retry, fail fast
                return result
            return result
        except Exception as e:
            last_error = e
            log.warning(f"OCR attempt {attempt}/{MAX_RETRIES} failed: {type(e).__name__}: {e}")
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_BACKOFF_S * attempt)   # exponential-ish backoff
    return {"error": f"OCR failed after {MAX_RETRIES} attempts: {last_error}"}


def execute_ocr(uploaded_file_bytes: bytes, original_filename: str, session_id: str) -> dict:
    """
    The single entry point the middleware calls. Takes raw bytes (from
    Streamlit's uploader), persists them to disk, runs the OCR engine
    with retry protection, and atomically logs the outcome.

    Returns the full run_pipeline() result dict PLUS a top-level
    'vault_status' key ('ok' | 'engine_error' | 'storage_write_failed')
    so the middleware can build a clean contract on top of it without
    guessing.
    """
    # [FIX] Previously used f"{uuid}_{original_filename}" as a flat filename
    # to avoid collisions. That underscore silently broke regex \b
    # word-boundary matching downstream (underscore counts as a "word"
    # character in regex, so a \w-to-\w transition at "..._EI-..." isn't a
    # boundary at all) — confirmed by testing, where document_reference
    # extraction picked a wrong, shorter match because the correct match's
    # starting position failed its \b assertion. A per-upload subdirectory
    # avoids collisions just as well while preserving the exact original
    # filename for anything downstream that reasonably wants to read it.
    upload_subdir = UPLOAD_DIR / uuid.uuid4().hex[:12]
    upload_subdir.mkdir(exist_ok=True)
    saved_path = upload_subdir / original_filename
    saved_path.write_bytes(uploaded_file_bytes)

    result = _execute_with_retry(saved_path, source_origin=f"streamlit_upload:{session_id}")

    if "error" in result:
        return {"vault_status": "engine_error", "error": result["error"],
                "file_name": original_filename, "session_id": session_id}

    # [Required by spec] atomic append-only execution log
    record = {
        "timestamp":  datetime.now(timezone.utc).isoformat(),
        "file_name":  original_filename,
        "raw_ocr_text": result.get("raw_text", result.get("markdown_text", "")),
        "session_id": session_id,
        # extra fields — cheap to keep, useful for debugging/analytics later
        "document_id": result.get("document_id"),
        "extraction_method": result.get("extraction_method"),
        "quality_tier": result.get("quality_tier"),
        "confidence_score": result.get("confidence_score"),
    }
    write_ok = _atomic_append(STORAGE_FILE, record)

    result["vault_status"] = "ok" if write_ok else "storage_write_failed"
    result["session_id"] = session_id
    return result


def log_correction(document_id: str, field: str, auto_value, corrected_value,
                    session_id: str) -> bool:
    """
    Records a human correction to an auto-extracted field. This is the
    flywheel's actual fuel — the Master Reference names doc type,
    revision number, date, and document reference as the fields most
    likely to need a human fix. Same atomic-write guarantee as the
    main OCR log, same lock file, so the two never interleave badly.
    """
    if str(auto_value) == str(corrected_value):
        return True  # no real correction happened, skip the write entirely
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "document_id": document_id,
        "field": field,
        "auto_value": auto_value,
        "corrected_value": corrected_value,
        "session_id": session_id,
    }
    return _atomic_append(CORRECTIONS_FILE, record)


def get_storage_stats() -> dict:
    """Cheap read-only summary for a sidebar/debug panel. Never writes."""
    records = _read_json_log(STORAGE_FILE)
    corrections = _read_json_log(CORRECTIONS_FILE)
    return {
        "total_documents_logged": len(records),
        "total_corrections_logged": len(corrections),
        "storage_file_size_kb": round(STORAGE_FILE.stat().st_size / 1024, 1) if STORAGE_FILE.exists() else 0,
    }
