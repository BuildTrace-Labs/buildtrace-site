#!/usr/bin/env python3
"""
============================================================
TraceConnect OCR Pipeline — ocr_pipeline.py
Version : 1.1.0  (Ref 0 — Gap-Fixed)
Licence : MIT / Apache-2.0 dependencies only (safe to commercialise)
============================================================

WHAT CHANGED IN v1.1.0 (gap-fix audit)
----------------------------------------
CRITICAL FIXES:
  [C1] Fingerprint registry — duplicate files detected at runtime
  [C2] Per-page output — pages[] array in every JSON output
  [C3] Failed queue — failed docs saved to failed_queue.json
  [C4] HEIC support — iPhone photos now handled via pillow-heif

HIGH FIXES:
  [H1] Quality scorer — base 0.5→0.3, construction keyword bonus
  [H2] BM month names — Ogos, Mei, Dis now normalised to ISO dates
  [H3] Docling quality gate added — falls through if garbled
  [H4] Language normaliser connected — intents stored in JSON
  [H5] Batch multiprocessing — ProcessPoolExecutor, 4 workers
  [H6] Language detection samples 3 sections not just first 2000 chars

MEDIUM FIXES:
  [M1] compression_pct clamped to 0.0, was_expanded flag added
  [M2] Scan metadata — DPI, contrast, dimensions for Tesseract
  [M3] Performance log — performance_log.jsonl per-run analytics
  [M4] Ground truth validation — --validate flag
  [M5] Feedback capture — human_corrections in every output JSON

DATA FLYWHEEL:
  [F1] human_corrections structure in output (training data)
  [F2] performance_log.jsonl — cross-document analytics
  [F3] failed_queue.json — retry infrastructure

NOTE: PyMuPDF is AGPL — replace with pdfplumber (MIT) before production.
============================================================
"""

import os, sys, json, time, uuid, hashlib, argparse, logging, re
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

# ── Third-party ───────────────────────────────────────────────────────────────
try:
    from markitdown import MarkItDown
    MARKITDOWN_AVAILABLE = True
except ImportError:
    MARKITDOWN_AVAILABLE = False
    print("WARNING: pip install markitdown[all]")

try:
    # [LICENCE FIX] Was PyMuPDF (fitz) — AGPL-3.0, flagged in requirements.txt
    # as "replace before commercial deployment." pdfplumber renders via
    # pypdfium2 under the hood (pure Python, MIT/Apache/BSD-family licensed,
    # no external Poppler/Ghostscript binary) — same rendering capability,
    # no AGPL exposure. This also implements Pillar 1 (Zero-Dependency PDF
    # Parsing) from the convert.py design framework directly in the main
    # pipeline, not just the standalone tool.
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    PDFPLUMBER_AVAILABLE = False
    print("WARNING: pip install pdfplumber")

try:
    # Optional: deskewing (tested, proven to help). Binarization exists in
    # this module too but defaults OFF — see preprocess.py's docstring for
    # why it measurably hurt modern Tesseract in direct testing.
    from preprocess import preprocess_for_ocr
    PREPROCESS_AVAILABLE = True
except ImportError:
    PREPROCESS_AVAILABLE = False
    print("WARNING: pip install opencv-python-headless numpy  (optional — enables deskew; pipeline works without it)")

try:
    import pytesseract
    from PIL import Image
    TESSERACT_AVAILABLE = True

    # [FIX] `pip install pytesseract` only installs a thin Python wrapper —
    # it does NOT install the actual Tesseract OCR program. On Windows
    # especially, it's common to have the package importable while the real
    # binary was never installed, or was installed but isn't on PATH. That
    # produced a confusing failure mode: TESSERACT_AVAILABLE was True (the
    # import succeeded), so the pipeline confidently entered the Tesseract
    # stage, then the first real call raised TesseractNotFoundError — caught
    # by the broad except below and reported as a generic "failed", with no
    # indication that it was actually an environment/install issue.
    #
    # This does two things: (1) tries common Windows install locations if
    # the binary isn't already on PATH, and (2) actually calls
    # get_tesseract_version() to verify a real, working binary exists —
    # not just that the Python package imported — so failures are caught
    # here with a clear message, instead of surfacing later as a mystery.
    import shutil as _shutil
    if _shutil.which("tesseract") is None:
        import os as _os
        _common_windows_paths = [
            r"C:\Program Files\Tesseract-OCR\tesseract.exe",
            r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        ]
        for _p in _common_windows_paths:
            if _os.path.isfile(_p):
                pytesseract.pytesseract.tesseract_cmd = _p
                break
    try:
        pytesseract.get_tesseract_version()
    except Exception as _e:
        TESSERACT_AVAILABLE = False
        print(f"WARNING: pytesseract (Python package) is installed, but the "
              f"Tesseract OCR *program* itself could not be found or run "
              f"({type(_e).__name__}). On Windows, install it from "
              f"https://github.com/UB-Mannheim/tesseract/wiki, then either "
              f"add it to PATH or set "
              f"pytesseract.pytesseract.tesseract_cmd to its .exe path.")
except ImportError:
    TESSERACT_AVAILABLE = False
    print("WARNING: pip install pytesseract pillow")

try:                                   # [C4] iPhone HEIC photos
    from pillow_heif import register_heif_opener
    register_heif_opener()
    HEIC_AVAILABLE = True
except ImportError:
    HEIC_AVAILABLE = False

try:
    import tiktoken
    try:
        TOKEN_ENCODER = tiktoken.get_encoding("cl100k_base")
        TIKTOKEN_AVAILABLE = True
    except Exception as e:
        # [FIX] tiktoken.get_encoding() fetches its vocab file over the network
        # at first use. In firewalled/offline/network-restricted environments
        # this raised an unhandled HTTPError and crashed the whole pipeline
        # before a single document was processed. Fall back to the char-count
        # estimator instead — count_tokens() already supports this path.
        TIKTOKEN_AVAILABLE = False
        TOKEN_ENCODER = None
        print(f"WARNING: tiktoken vocab fetch failed ({type(e).__name__}) — "
              f"using char-count token estimate instead")
except ImportError:
    TIKTOKEN_AVAILABLE = False
    TOKEN_ENCODER = None
    print("WARNING: pip install tiktoken")

try:
    from langdetect import detect as _detect_lang, DetectorFactory
    DetectorFactory.seed = 42
    LANGDETECT_AVAILABLE = True
except ImportError:
    LANGDETECT_AVAILABLE = False

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("TraceConnect.OCR")

# ── Paths ─────────────────────────────────────────────────────────────────────
OUTPUT_DIR           = Path("ocr_outputs"); OUTPUT_DIR.mkdir(exist_ok=True)
FINGERPRINT_REGISTRY = OUTPUT_DIR / "fingerprint_registry.json"   # [C1]
FAILED_QUEUE         = OUTPUT_DIR / "failed_queue.json"           # [C3]
PERFORMANCE_LOG      = OUTPUT_DIR / "performance_log.jsonl"       # [M3]

# ── Supported types ────────────────────────────────────────────────────────────
SUPPORTED_TYPES = {
    ".pdf":"markitdown", ".docx":"markitdown", ".doc":"markitdown",
    ".xlsx":"markitdown", ".xls":"markitdown", ".pptx":"markitdown",
    ".ppt":"markitdown",  ".msg":"markitdown",  ".eml":"markitdown",
    ".html":"markitdown", ".htm":"markitdown",  ".txt":"markitdown",
    ".md":"markitdown",   ".csv":"markitdown",
    ".png":"tesseract",   ".jpg":"tesseract",   ".jpeg":"tesseract",
    ".tiff":"tesseract",  ".bmp":"tesseract",   ".webp":"tesseract",
    ".heic":"tesseract",  ".heif":"tesseract",  # [C4]
}

# ── Thresholds ────────────────────────────────────────────────────────────────
MIN_MARKDOWN_LENGTH  = 100
MIN_MARKITDOWN_SCORE = 0.40
MIN_DOCLING_SCORE    = 0.35   # [H3]
GREEN_CONFIDENCE     = 0.85
AMBER_CONFIDENCE     = 0.60

# ── Construction keywords for scoring ─────────────────────────────────────────
# [H1] Reward OCR output that contains recognisable construction content
CONSTRUCTION_KEYWORDS = [
    "drawing","revision","instruction","approved","site","contractor",
    "architect","engineer","level","beam","concrete","column","slab",
    "rfi","variation","ncr","issue","specification","schedule",
    "meeting","minutes","letter","report","lukisan","arahan",
    "kelulusan","jurutera","arkitek",
]

# ── BM month names for date normalisation ─────────────────────────────────────
# [H2] "14 Ogos 2026" → "2026-08-14"
BM_MONTHS = {
    "jan":"01","feb":"02","mac":"03","apr":"04","mei":"05","jun":"06",
    "jul":"07","ogo":"08","ogos":"08","sep":"09","okt":"10","nov":"11","dis":"12",
}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 1 — REGISTRY & QUEUE HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def load_registry() -> dict:
    """[C1] Load SHA-256 fingerprint registry."""
    try:
        return json.loads(FINGERPRINT_REGISTRY.read_text(encoding="utf-8")) \
               if FINGERPRINT_REGISTRY.exists() else {}
    except Exception:
        return {}

def save_registry(r: dict):
    FINGERPRINT_REGISTRY.write_text(json.dumps(r, indent=2, ensure_ascii=False), encoding="utf-8")

def load_failed_queue() -> list:
    """[C3] Load retry queue."""
    try:
        return json.loads(FAILED_QUEUE.read_text(encoding="utf-8")) \
               if FAILED_QUEUE.exists() else []
    except Exception:
        return []

def save_failed_queue(q: list):
    FAILED_QUEUE.write_text(json.dumps(q, indent=2, ensure_ascii=False), encoding="utf-8")

def append_performance_log(entry: dict):
    """[M3] Append one JSONL line per document to performance log."""
    try:
        with open(PERFORMANCE_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as e:
        log.warning(f"Perf log write failed: {e}")


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 2 — UTILITY FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════════

def count_tokens(text: str) -> int:
    if not TIKTOKEN_AVAILABLE or not text:
        return len(text) // 4
    return len(TOKEN_ENCODER.encode(text))

def get_file_fingerprint(fp: Path) -> str:
    h = hashlib.sha256()
    with open(fp, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def detect_language_safe(text: str) -> str:
    """
    [H6] Sample start + middle + end to catch mixed BM/English documents.
    Previously only checked first 2000 chars — missed BM in body of long docs.
    """
    if not LANGDETECT_AVAILABLE or not text or len(text) < 50:
        return "unknown"
    n = len(text)
    samples = [text[:1000], text[n//2:n//2+1000], text[max(0,n-1000):]]
    detected = []
    for s in samples:
        if len(s.strip()) < 30:
            continue
        try:
            detected.append(_detect_lang(s))
        except Exception:
            pass
    if not detected:
        return "unknown"
    if "ms" in detected:
        return "mixed" if "en" in detected else "ms"
    if all(d == "en" for d in detected):
        return "en"
    return "mixed"

def get_quality_tier(c: float) -> str:
    return "green" if c >= GREEN_CONFIDENCE else "amber" if c >= AMBER_CONFIDENCE else "red"

def get_quality_flags(text: str, confidence: float, method: str) -> list:
    flags = []
    if confidence < AMBER_CONFIDENCE:
        flags.append("low_confidence")
    if not text or len(text.strip()) < 50:
        flags.append("empty_or_too_short")
    if text:
        non_alpha = sum(1 for c in text if not c.isalnum() and c not in " \n.,;:-/()[]")
        if non_alpha / max(len(text), 1) > 0.35:
            flags.append("possible_garbled_text")
    if method == "tesseract" and confidence < 0.7:
        flags.append("scanned_document_low_quality")
    return flags

def make_feedback_template() -> dict:
    """
    [F1] Human corrections template.
    Every field a user corrects = one training example.
    Populated by the UI layer, stored permanently in JSON.
    """
    fields = ["canonical_document_type","revision_number","document_date","document_reference"]
    return {f: {"auto_extracted":None,"human_corrected":None,
                "corrected_by":None,"corrected_at":None} for f in fields}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 3 — MARKDOWN QUALITY SCORER  [H1]
# ══════════════════════════════════════════════════════════════════════════════

def score_markdown_quality(text: str) -> dict:
    """
    [H1] Improved scorer.
    - Base score lowered 0.5 → 0.3 (was too generous)
    - Construction keyword bonus: +0.20 if 2+ keywords, +0.10 if 5+
    - Garbled scan stays low even with some content
    """
    if not text or len(text) < MIN_MARKDOWN_LENGTH:
        return {"score":0.0,"headings_count":0,"tables_count":0,
                "lists_count":0,"char_count":len(text) if text else 0,
                "assessment":"empty_or_too_short","keyword_hits":0,"garble_ratio":0}

    lines    = text.split("\n")
    headings = sum(1 for l in lines if l.strip().startswith("#"))
    tables   = sum(1 for l in lines if "|" in l and l.count("|") >= 2)
    lists    = sum(1 for l in lines if l.strip().startswith(("-","*","•")))

    non_alpha    = sum(1 for c in text if not c.isalnum() and c not in " \n#|*-.,;:/()`>_~")
    garble_ratio = non_alpha / max(len(text), 1)
    text_lower   = text.lower()
    keyword_hits = sum(1 for k in CONSTRUCTION_KEYWORDS if k in text_lower)

    score = 0.30                          # [H1] was 0.50
    if headings > 0:     score += 0.12
    if headings > 3:     score += 0.08
    if tables   > 0:     score += 0.12
    if lists    > 0:     score += 0.08
    if keyword_hits >= 2: score += 0.20  # [H1] construction content confirmed
    if keyword_hits >= 5: score += 0.10  # [H1] strongly construction-specific
    if garble_ratio > 0.3: score -= 0.30
    if garble_ratio > 0.5: score -= 0.20
    if len(text) < 200:   score -= 0.20

    score = max(0.0, min(1.0, round(score, 2)))
    assessment = ("excellent" if score>=0.8 else "good" if score>=0.6
                  else "acceptable" if score>=0.4 else "poor")

    return {"score":score,"headings_count":headings,"tables_count":tables,
            "lists_count":lists,"char_count":len(text),"assessment":assessment,
            "keyword_hits":keyword_hits,"garble_ratio":round(garble_ratio,3)}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 4 — CONSTRUCTION ENHANCER  [H2]
# ══════════════════════════════════════════════════════════════════════════════

def enhance_for_construction(text: str) -> str:
    """
    Tag construction refs, revisions, action items, decisions.
    [H2] Extended: BM month names now normalised to ISO dates.
    """
    if not text:
        return text

    # Tag doc references
    text = re.sub(
        r'\b(RFI|AI|VO|NCR|SI|PCN|DWG|SPEC|MOM|SR|CO|CVI|EI)[-\s]?(\d{1,4})\b',
        r'`\1-\2`', text, flags=re.IGNORECASE)

    # Tag revision numbers
    text = re.sub(r'\b(Rev(?:ision)?\.?\s?)([A-Z0-9]{1,2})\b',
                  r'`Rev \2`', text, flags=re.IGNORECASE)

    # Numeric dates: 14/08/2026 → 2026-08-14
    def normalise_dmy(m):
        d,mo,y = m.group(1),m.group(2),m.group(3)
        return f"{y}-{mo.zfill(2)}-{d.zfill(2)}"
    text = re.sub(r'\b(\d{1,2})[/\-](\d{1,2})[/\-](\d{4})\b', normalise_dmy, text)

    # [H2] BM month names: "14 Ogos 2026" → "2026-08-14"
    def normalise_bm(m):
        d   = m.group(1).replace("hb","").strip()
        mon = m.group(2).lower()
        y   = m.group(3)
        num = BM_MONTHS.get(mon)
        return f"{y}-{num}-{d.zfill(2)}" if num else m.group(0)
    bm_pat = "|".join(BM_MONTHS.keys())
    text = re.sub(rf'\b(\d{{1,2}}(?:hb)?)\s+({bm_pat})\s+(\d{{4}})\b',
                  normalise_bm, text, flags=re.IGNORECASE)

    # [FIX] Full English month names: "18 NOVEMBER 2019" -> "2019-11-18"
    # Missing case found while testing against a real Engineer's Instruction —
    # the numeric-date and BM-month regexes above didn't cover this format,
    # so English-dated documents (common from consultants/engineers, as
    # opposed to contractors who more often write BM dates) were passing
    # through with their date left un-normalised.
    EN_MONTHS = {"january":"01","february":"02","march":"03","april":"04","may":"05",
                 "june":"06","july":"07","august":"08","september":"09",
                 "october":"10","november":"11","december":"12"}
    def normalise_en(m):
        d, mon, y = m.group(1), m.group(2).lower(), m.group(3)
        num = EN_MONTHS.get(mon)
        return f"{y}-{num}-{d.zfill(2)}" if num else m.group(0)
    en_pat = "|".join(EN_MONTHS.keys())
    text = re.sub(rf'\b(\d{{1,2}})\s+({en_pat})\s+(\d{{4}})\b',
                  normalise_en, text, flags=re.IGNORECASE)

    # Bold action words
    for word in ["shall","must","required to","instructed to","submit within",
                 "resubmit","provide","confirm","respond within","action required"]:
        text = re.sub(rf'\b({re.escape(word)})\b', r'**\1**', text, flags=re.IGNORECASE)

    # Blockquote decisions
    dec_words = ["approved","rejected","confirmed","agreed","decided","resolved"]
    lines = text.split("\n")
    text  = "\n".join(
        ("> "+l if any(w in l.lower() for w in dec_words) and not l.startswith(">") else l)
        for l in lines
    )
    return text


def extract_document_metadata(text: str, filename: str) -> dict:
    """
    [NEW] Auto-extracts the four fields that were previously always None:
    canonical_document_type, document_reference, revision_number, document_date.

    Built against real patterns observed in actual construction documents
    (an Engineer's Instruction from M.E.I. Consultants, plus synthetic
    RFI/AI test docs) — not guessed from first principles. Heuristic,
    not ML: cheap, fast, fully deterministic, and — critically — every
    field it gets wrong becomes a human correction in ocr_corrections.json,
    which is exactly the training signal needed to make it better over
    time. This does NOT require a trained model to get started; see the
    note at the bottom of this function for why.
    """
    result = {"canonical_document_type": None, "document_reference": None,
              "revision_number": None, "document_date": None}
    if not text:
        return result

    # ── Document type — keyword match, robust to OCR reading-order chaos
    # since a heading's words usually stay adjacent even when tables around
    # it get jumbled. Ordered so more specific phrases are checked first.
    DOC_TYPE_PATTERNS = [
        (r"ENGINEER[''\u2019]?S?\s+INSTRUCTION", "Engineer's Instruction"),
        (r"ARCHITECT[''\u2019]?S?\s+INSTRUCTION", "Architect Instruction"),
        (r"CONFIRMATION\s+OF\s+VERBAL\s+INSTRUCTION", "Confirmation of Verbal Instruction"),
        (r"REQUEST\s+FOR\s+INFORMATION", "Request for Information"),
        (r"SITE\s+INSTRUCTION", "Site Instruction"),
        (r"VARIATION\s+ORDER", "Variation Order"),
        (r"NON.?CONFORMANCE\s+REPORT", "Non-Conformance Report"),
        (r"MINUTES\s+OF\s+MEETING", "Minutes of Meeting"),
        (r"SITE\s+(?:DAILY\s+)?REPORT", "Site Report"),
        (r"PAYMENT\s+CERTIFICATE", "Payment Certificate"),
    ]
    for pattern, canonical in DOC_TYPE_PATTERNS:
        if re.search(pattern, text, re.IGNORECASE):
            result["canonical_document_type"] = canonical
            break

    # ── Document reference — two sources, filename first.
    # Filename is often the MOST reliable source: many firms name files
    # exactly after the document's own reference number (confirmed by this
    # real EI document — "EI-81893C-P5000-CSA-005.pdf" IS the reference),
    # and it's immune to OCR reading-order problems entirely since it
    # never went through OCR at all.
    REF_PATTERN = re.compile(r'\b([A-Z]{2,6}-[A-Z0-9]+(?:-[A-Z0-9]+){0,4})\b')
    stem = Path(filename).stem.upper()
    m = REF_PATTERN.search(stem)
    if m:
        result["document_reference"] = m.group(1)
    else:
        # Fallback: search near the top of the extracted text, where a
        # document's own reference typically appears (as opposed to
        # references to OTHER documents — drawings, prior letters — which
        # tend to appear further down, in body content).
        head = text[:600]
        m = REF_PATTERN.search(head)
        if m:
            result["document_reference"] = m.group(1)

    # ── Revision number — explicit "Rev X" pattern, restricted to the
    # HEADER area only (first ~800 chars). Confirmed necessary by testing:
    # searching the full body wrongly matched "Rev 1" from a REFERENCED
    # drawing's revision inside the instruction text, not the document's
    # own revision. Many document types (like an Engineer's Instruction)
    # genuinely have no revision of their own — only the drawings/items
    # they reference do — so returning None here is often correct, not
    # a missed extraction. Don't force a guess where none belongs.
    header_zone = text[:800]
    m = re.search(r'\bRev(?:ision)?\.?\s*([A-Z]|\d{1,2})\b(?!\s*\d)', header_zone, re.IGNORECASE)
    if m:
        result["revision_number"] = m.group(1).upper()

    # ── Document date — prefer an ISO date near the word "Date", since
    # enhance_for_construction() already normalises BM/English/numeric
    # dates to ISO before this function runs. Falls back to the first ISO
    # date anywhere in the first page if no labelled one is found.
    date_near_label = re.search(r'Date\s*:?\s*(\d{4}-\d{2}-\d{2})', text)
    if date_near_label:
        result["document_date"] = date_near_label.group(1)
    else:
        any_date = re.search(r'\b(\d{4}-\d{2}-\d{2})\b', text[:1500])
        if any_date:
            result["document_date"] = any_date.group(1)

    return result

# NOTE ON "DO WE NEED TO TRAIN A MODEL FOR THIS":
# No — not for this part. These four fields follow a small set of
# well-defined formatting conventions across a whole industry (standard
# document-type names, reference-number patterns, revision letters, date
# formats) — that's exactly the situation regex/heuristic extraction
# handles well, with zero training data required. Model training earns
# its cost when patterns are too varied or context-dependent for
# hand-written rules to generalise (e.g. freeform paragraph
# summarisation, or classifying ambiguous intent). The corrections
# logged in ocr_corrections.json are still valuable here — they're what
# tells you WHEN this heuristic is wrong often enough to be worth
# revisiting, and on which document types/issuers specifically.



def split_into_pages(file_path: Path, full_text: str, method: str) -> list:
    """
    [C2] Split extracted text into per-page records.
    Previously the whole document was one text blob.
    Now each page has its own record with page_number — enabling
    the AI assistant to cite exact page numbers in answers.
    """
    suffix = file_path.suffix.lower()
    pages  = []

    # PDF: use pdfplumber for accurate per-page native text
    if suffix == ".pdf" and PDFPLUMBER_AVAILABLE and method in ("markitdown","docling"):
        try:
            with pdfplumber.open(str(file_path)) as pdf:
                total = len(pdf.pages)
                for i, page in enumerate(pdf.pages, 1):
                    pt = page.extract_text() or ""
                    pages.append({
                        "page_number":    i,
                        "total_pages":    total,
                        "raw_text":       pt.strip(),
                        "markdown_text":  enhance_for_construction(pt),
                        "token_count":    count_tokens(pt),
                        "confidence_score": 0.90 if pt.strip() else 0.30,
                        "is_empty":       len(pt.strip()) < 20,
                    })
            if pages:
                return pages
        except Exception as e:
            log.warning(f"Per-page PDF split failed: {e}")

    # Image: single page
    if suffix in (".png",".jpg",".jpeg",".tiff",".bmp",".webp",".heic",".heif"):
        return [{"page_number":1,"total_pages":1,"raw_text":full_text,
                 "markdown_text":full_text,"token_count":count_tokens(full_text),
                 "confidence_score":0.65,"is_empty":len(full_text.strip())<20}]

    # DOCX/other: split by headings or use as single section
    if "\n# " in full_text:
        sections = re.split(r'\n(?=# )', full_text)
        for i, sec in enumerate(sections, 1):
            if sec.strip():
                pages.append({"page_number":i,"total_pages":len(sections),
                              "raw_text":sec.strip(),"markdown_text":sec.strip(),
                              "token_count":count_tokens(sec),"confidence_score":0.88,
                              "is_empty":False})
        if pages:
            return pages

    # Fallback: entire doc as page 1
    return [{"page_number":1,"total_pages":1,"raw_text":full_text,
             "markdown_text":full_text,"token_count":count_tokens(full_text),
             "confidence_score":0.80,"is_empty":len(full_text.strip())<20}]


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 6 — LANGUAGE NORMALISER INTEGRATION  [H4]
# ══════════════════════════════════════════════════════════════════════════════

def run_language_normaliser(text: str) -> dict:
    """
    [H4] Connect language_normaliser.py to OCR pipeline.
    Previously the two scripts were completely separate — no data sharing.
    Now normaliser output (intents, BM terms, particles) is stored in JSON.
    """
    try:
        from language_normaliser import MalaysianLanguageNormaliser
        r = MalaysianLanguageNormaliser().normalise(text[:5000])
        return {
            "normalised_text":       r.get("normalised_text", text),
            "language_profile":      r.get("language_profile", {}),
            "intents_detected":      r.get("intents_detected", []),
            "bm_translations_count": len(r.get("bm_translations", [])),
            "particles_found":       r.get("particles_found", []),
            "broken_fixes":          r.get("broken_fixes", 0),
            "was_normalised":        r.get("was_normalised", False),
            "normaliser_confidence": r.get("confidence", 0.0),
        }
    except ImportError:
        log.debug("language_normaliser.py not found in same folder")
        return {"normalised_text":text,"language_profile":{},"intents_detected":[],
                "bm_translations_count":0,"particles_found":[],"broken_fixes":0,
                "was_normalised":False,"normaliser_confidence":0.0}
    except Exception as e:
        log.warning(f"Language normaliser error: {e}")
        return {"normalised_text":text,"was_normalised":False}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 7 — SCAN METADATA  [M2]
# ══════════════════════════════════════════════════════════════════════════════

def get_scan_metadata(img: "Image.Image") -> dict:
    """
    [M2] Record technical image quality metadata for Tesseract runs.
    Used to train a pre-processing step that improves scans before OCR.
    """
    try:
        w, h     = img.size
        dpi_info = img.info.get("dpi", (72, 72))
        dpi      = int(dpi_info[0]) if isinstance(dpi_info, tuple) else 72
        grey     = img.convert("L")
        pixels   = list(grey.getdata())
        avg      = sum(pixels) / max(len(pixels), 1)
        contrast = round(avg / 255, 3)
        return {"image_width_px":w,"image_height_px":h,"dpi":dpi,
                "contrast_score":contrast,"is_low_contrast":contrast<0.4 or contrast>0.9,
                "aspect_ratio":round(w/max(h,1),2),"likely_landscape":w>h}
    except Exception:
        return {"dpi":None,"image_width_px":None,"image_height_px":None}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 8 — STAGE 0: MARKITDOWN
# ══════════════════════════════════════════════════════════════════════════════

def extract_with_markitdown(fp: Path) -> dict:
    if not MARKITDOWN_AVAILABLE:
        return {"success":False,"reason":"markitdown_not_installed"}
    log.info(f"Stage 0 — MarkItDown: {fp.name}")
    t0 = time.time()
    try:
        res  = MarkItDown().convert(str(fp))
        text = res.text_content if hasattr(res,"text_content") else str(res)
        q    = score_markdown_quality(text)
        if q["score"] < MIN_MARKITDOWN_SCORE:
            log.warning(f"MarkItDown low quality ({q['score']:.2f}) — falling through")
            return {"success":False,"reason":f"quality_too_low_{q['assessment']}",
                    "quality_score":q["score"],"raw_attempt":text[:500]}
        enhanced = enhance_for_construction(text)
        elapsed  = round(time.time()-t0, 2)
        log.info(f"MarkItDown OK: quality={q['score']:.2f} time={elapsed}s")
        return {"success":True,"method":"markitdown","markdown_text":enhanced,
                "raw_markdown":text,"quality":q,"token_count":count_tokens(enhanced),
                "processing_time_s":elapsed}
    except Exception as e:
        log.error(f"MarkItDown exception: {e}")
        return {"success":False,"reason":f"exception_{type(e).__name__}","error":str(e)}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 9 — STAGE 1: DOCLING  [H3]
# ══════════════════════════════════════════════════════════════════════════════

def extract_with_docling(fp: Path) -> dict:
    """
    [H3] Quality gate added — garbled Docling output now falls through
    to Tesseract. Previously Docling could silently return junk and be accepted.
    """
    log.info(f"Stage 1 — Docling: {fp.name}")
    t0 = time.time()
    try:
        from docling.document_converter import DocumentConverter
        res  = DocumentConverter().convert(str(fp))
        text = res.document.export_to_markdown()
        q    = score_markdown_quality(text)
        if q["score"] < MIN_DOCLING_SCORE:   # [H3]
            log.warning(f"Docling low quality ({q['score']:.2f}) — falling through")
            return {"success":False,"reason":f"docling_quality_too_low_{q['score']:.2f}",
                    "quality_score":q["score"]}
        enhanced = enhance_for_construction(text)
        elapsed  = round(time.time()-t0, 2)
        log.info(f"Docling OK: quality={q['score']:.2f} time={elapsed}s")
        return {"success":True,"method":"docling","markdown_text":enhanced,
                "raw_markdown":text,"quality":q,"token_count":count_tokens(enhanced),
                "processing_time_s":elapsed}
    except ImportError:
        return {"success":False,"reason":"docling_not_installed"}
    except Exception as e:
        log.error(f"Docling exception: {e}")
        return {"success":False,"reason":f"exception_{type(e).__name__}","error":str(e)}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 10 — STAGE 2: TESSERACT  [C4] [M2]
# ══════════════════════════════════════════════════════════════════════════════

def extract_with_tesseract(fp: Path) -> dict:
    """
    [C4] HEIC added — iPhone photos now processed.
    [M2] Scan metadata recorded for training pre-processing models.
    [PILLAR 2 — Hybrid Text Fallback] Previously this stage rendered and
    OCR'd EVERY page unconditionally, even ones that already have a real
    text layer. Two real problems with that: it silently wastes time (OCR
    is far slower than reading embedded text), and it's LESS ACCURATE —
    forcing a perfectly good native-text page through OCR can only degrade
    it, never improve it. This only reaches this stage as the last resort
    of the cascade, but a real construction document can still be MIXED —
    e.g. a native-text cover page followed by a scanned signature page —
    so per-page checking still matters even here, not just at the
    document level.
    """
    if not TESSERACT_AVAILABLE:
        return {"success":False,"reason":"tesseract_not_installed"}
    log.info(f"Stage 2 — Tesseract: {fp.name}")
    t0 = time.time()
    try:
        suffix     = fp.suffix.lower()
        all_text   = ""
        pages_data = []
        scan_meta  = {}
        ocr_pages_count = 0   # how many pages actually needed OCR

        if suffix == ".pdf" and PDFPLUMBER_AVAILABLE:
            with pdfplumber.open(str(fp)) as pdf:
                total = len(pdf.pages)
                for i, page in enumerate(pdf.pages, start=1):
                    native_text = page.extract_text() or ""
                    if native_text.strip():
                        # Real text layer present — use it directly, skip
                        # OCR for this page entirely. More accurate AND
                        # faster than forcing it through OCR.
                        pt = native_text
                    else:
                        # [PILLAR 3 — Sandbox Image Buffering] rendered
                        # straight into an in-memory PIL.Image via
                        # pypdfium2 — never written to disk.
                        img = page.to_image(resolution=300).original
                        if i == 1 or not scan_meta:
                            scan_meta = get_scan_metadata(img)   # [M2]
                        if PREPROCESS_AVAILABLE:
                            img, skew_angle = preprocess_for_ocr(img)
                            if abs(skew_angle) >= 0.3:
                                log.info(f"  Page {i}: corrected {skew_angle:.1f}° skew")
                        try:
                            pt = pytesseract.image_to_string(img,lang="eng+msa",config="--psm 3")
                        except Exception:
                            pt = pytesseract.image_to_string(img,config="--psm 3")
                        ocr_pages_count += 1
                    all_text += f"\n\n--- Page {i} ---\n\n{pt}"
                    pages_data.append({"page_number":i,"total_pages":total,
                                       "raw_text":pt.strip(),"token_count":count_tokens(pt),
                                       "was_ocrd":bool(not native_text.strip())})
            log.info(f"Hybrid extraction: {ocr_pages_count}/{total} page(s) needed OCR, "
                     f"rest used native text")

        elif suffix in (".png",".jpg",".jpeg",".tiff",".bmp",".webp",".heic",".heif"):
            img       = Image.open(str(fp)).convert("RGB")   # [C4] HEIC works here
            scan_meta = get_scan_metadata(img)                # [M2]
            if PREPROCESS_AVAILABLE:
                # Highest-value case for deskew — real phone/WhatsApp
                # photos are far more likely to be tilted than a
                # programmatically-rendered PDF page.
                img, skew_angle = preprocess_for_ocr(img)
                if abs(skew_angle) >= 0.3:
                    log.info(f"  Corrected {skew_angle:.1f}° skew")
            try:
                all_text = pytesseract.image_to_string(img,lang="eng+msa",config="--psm 3")
            except Exception:
                all_text = pytesseract.image_to_string(img,config="--psm 3")
            pages_data = [{"page_number":1,"total_pages":1,
                           "raw_text":all_text.strip(),"token_count":count_tokens(all_text)}]
        else:
            return {"success":False,"reason":f"unsupported_type_{suffix}"}

        enhanced = enhance_for_construction(all_text)
        q        = score_markdown_quality(enhanced)
        elapsed  = round(time.time()-t0, 2)
        log.info(f"Tesseract OK: pages={len(pages_data)} quality={q['score']:.2f} time={elapsed}s")
        return {"success":True,"method":"tesseract","markdown_text":enhanced,
                "raw_markdown":all_text,"quality":q,"token_count":count_tokens(enhanced),
                "processing_time_s":elapsed,"pages_data":pages_data,"scan_metadata":scan_meta}

    except Exception as e:
        log.error(f"Tesseract exception: {e}")
        return {"success":False,"reason":f"exception_{type(e).__name__}","error":str(e)}


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 11 — MAIN PIPELINE  (all fixes wired in)
# ══════════════════════════════════════════════════════════════════════════════

def run_pipeline(file_path: Path, compare_mode: bool = False,
                 source_origin: str = "manual_upload") -> dict:
    fp = Path(file_path)
    if not fp.exists():
        return {"error":f"File not found: {fp}"}
    suffix = fp.suffix.lower()
    if suffix not in SUPPORTED_TYPES:
        return {"error":f"Unsupported file type: {suffix}"}

    # [C1] Duplicate check
    fingerprint = get_file_fingerprint(fp)
    registry    = load_registry()
    if not compare_mode and fingerprint in registry:
        cached_path = Path(registry[fingerprint].get("result_path",""))
        if cached_path.exists():
            log.info(f"DUPLICATE → cached: {fp.name}")
            try:
                r = json.loads(cached_path.read_text(encoding="utf-8"))
                r["_from_cache"] = True
                return r
            except Exception:
                log.warning("Cache read failed — reprocessing")

    doc_id    = str(uuid.uuid4())
    size_kb   = round(fp.stat().st_size / 1024, 1)
    ts        = datetime.now(timezone.utc).isoformat()
    log.info(f"Processing: {fp.name} ({size_kb} KB) [{doc_id[:8]}]")

    if compare_mode:
        results = {"markitdown":extract_with_markitdown(fp),
                   "docling":extract_with_docling(fp),
                   "tesseract":extract_with_tesseract(fp)}
        return build_comparison_output(doc_id, fp, results, ts)

    # Stage cascade
    extraction = None
    fallbacks  = []
    method     = "failed"
    stage_errs = {}

    r0 = extract_with_markitdown(fp)
    if r0["success"]:
        extraction, method = r0, "markitdown"
    else:
        stage_errs["markitdown"] = r0.get("reason","?")
        fallbacks.append(f"markitdown: {r0.get('reason','?')}")

        # [PERFORMANCE FIX] Skip Docling when MarkItDown found LITERALLY
        # zero extractable characters — a strong, direct signal this is a
        # pure scanned image with no text layer at all. Docling's real
        # value is LAYOUT-awareness (tables, complex structure) applied
        # to text that exists; with zero text, there's nothing for that
        # to work on, and Docling still pays its full model-download
        # cost trying. Measured directly on a real 2-page scanned
        # document: Docling alone took 67.6s of a 76.7s total run (88%)
        # before failing over anyway — pure wasted time for this case.
        # A document with SOME text (just low-quality/garbled) still
        # goes through Docling normally below, since that's exactly the
        # case its layout-awareness can actually help with.
        raw_chars = len(r0.get("raw_attempt", ""))
        if raw_chars == 0:
            log.info(f"MarkItDown found zero text — skipping Docling "
                     f"(pure scan, no layout-aware benefit possible), "
                     f"going straight to Tesseract")
            stage_errs["docling"] = "skipped_zero_native_text"
            fallbacks.append("docling: skipped (zero native text — pure scan)")
            r2 = extract_with_tesseract(fp)
            if r2["success"]:
                extraction, method = r2, "tesseract"
            else:
                stage_errs["tesseract"] = r2.get("reason","?")
                fallbacks.append(f"tesseract: {r2.get('reason','?')}")
                log.error(f"ALL STAGES FAILED: {fp.name}")
        else:
            r1 = extract_with_docling(fp)
            if r1["success"]:
                extraction, method = r1, "docling"
            else:
                stage_errs["docling"] = r1.get("reason","?")
                fallbacks.append(f"docling: {r1.get('reason','?')}")
                r2 = extract_with_tesseract(fp)
                if r2["success"]:
                    extraction, method = r2, "tesseract"
                else:
                    stage_errs["tesseract"] = r2.get("reason","?")
                    fallbacks.append(f"tesseract: {r2.get('reason','?')}")
                    log.error(f"ALL STAGES FAILED: {fp.name}")

    # [C3] Record failure
    if not extraction:
        q = load_failed_queue()
        q.append({"file":str(fp),"file_name":fp.name,"fingerprint":fingerprint,
                  "failed_at":ts,"retry_count":0,"stage_errors":stage_errs})
        save_failed_queue(q)

    # Extract fields
    if extraction:
        md_text   = extraction.get("markdown_text","")
        raw_text  = extraction.get("raw_markdown", md_text)
        quality   = extraction.get("quality",{})
        tok       = extraction.get("token_count", count_tokens(md_text))
        proc_t    = extraction.get("processing_time_s",0)
        conf      = quality.get("score",0.5)
        scan_meta = extraction.get("scan_metadata",{})
    else:
        md_text = raw_text = ""
        quality = {"score":0.0,"assessment":"failed"}
        tok = proc_t = conf = 0
        scan_meta = {}

    # [C2] Per-page split
    # [BUG FIX] extract_with_tesseract() already computes accurate
    # per-page data during hybrid extraction (which pages needed OCR,
    # which used native text) — but this used to be discarded every
    # time in favour of split_into_pages(), which only has real PDF
    # per-page logic for markitdown/docling and silently collapsed
    # tesseract-method multi-page PDFs down to a single page. Found by
    # testing the real EI document (2 pages) and seeing total_pages: 1
    # in the output. Now: reuse the extraction stage's own pages_data
    # when it's already there and reliable; only fall back to
    # split_into_pages() when the extraction method didn't produce one.
    if extraction and extraction.get("pages_data"):
        pages = []
        for pd in extraction["pages_data"]:
            raw = pd.get("raw_text", "")
            pages.append({
                "page_number": pd["page_number"],
                "total_pages": pd["total_pages"],
                "raw_text": raw,
                "markdown_text": enhance_for_construction(raw),
                "token_count": pd.get("token_count", count_tokens(raw)),
                "confidence_score": 0.90 if not pd.get("was_ocrd", True) else 0.65,
                "is_empty": len(raw.strip()) < 20,
            })
    else:
        pages = split_into_pages(fp, md_text, method)

    # [H4] Language normaliser
    norm = run_language_normaliser(md_text)

    # [H6] Multi-section language detection
    lang  = detect_language_safe(md_text)
    tier  = get_quality_tier(conf)
    flags = get_quality_flags(md_text, conf, method)

    # [M1] Token compression — clamped
    raw_tok = count_tokens(raw_text)
    comp    = max(0.0, round((1 - tok/raw_tok)*100, 1)) if raw_tok > 0 and tok > 0 else 0.0

    out = {
        # Identity
        "document_id":doc_id,
        "file_name":fp.name,"file_path":str(fp),
        "file_type":suffix.lstrip("."),"file_size_kb":size_kb,
        "document_fingerprint":fingerprint,"source_origin":source_origin,
        "_from_cache":False,
        # Extraction
        "extraction_method":method,"extraction_fallbacks":fallbacks,
        "processing_time_s":proc_t,"extraction_timestamp":ts,
        # Quality
        "confidence_score":conf,"quality_tier":tier,"quality_flags":flags,
        "markdown_quality":quality,"scan_metadata":scan_meta,  # [M2]
        # Content
        "language_detected":lang,"markdown_text":md_text,"raw_text":raw_text,
        # [C2] Pages
        "pages":pages,"total_pages":len(pages),
        # Tokens [M1]
        "token_count":tok,"raw_token_count":raw_tok,
        "compression_pct":comp,"was_expanded":tok>raw_tok,
        # [H4] Normaliser
        "normalised_text":norm.get("normalised_text",md_text),
        "language_profile":norm.get("language_profile",{}),
        "intents_detected":norm.get("intents_detected",[]),
        "bm_translations_count":norm.get("bm_translations_count",0),
        "particles_found":norm.get("particles_found",[]),
        "was_normalised":norm.get("was_normalised",False),
        # Status
        "status":"ready" if extraction else "failed",
        # Metadata — auto-extracted (was hardcoded None before)
        **extract_document_metadata(md_text, fp.name),
        "sender":None,"recipient":None,
        # Thread placeholders
        "is_superseded":False,"superseded_by":None,"thread_parent_id":None,
        # [F1] Feedback capture — training data for the flywheel
        "human_corrections":make_feedback_template(),
    }

    # [C1] Register fingerprint
    if extraction:
        stem = fp.stem
        registry[fingerprint] = {"document_id":doc_id,"file_name":fp.name,
                                  "result_path":str(OUTPUT_DIR/f"{stem}_ocr.json"),
                                  "processed_at":ts}
        save_registry(registry)

    # [M3] Performance log
    append_performance_log({
        "document_id":doc_id,"file_name":fp.name,"file_type":suffix.lstrip("."),
        "file_size_kb":size_kb,"method_used":method,"fallbacks":len(fallbacks),
        "quality_score":conf,"quality_tier":tier,"token_count":tok,
        "compression_pct":comp,"total_pages":len(pages),
        "intents_count":len(norm.get("intents_detected",[])),
        "bm_count":norm.get("bm_translations_count",0),
        "was_normalised":norm.get("was_normalised",False),
        "language":lang,"status":out["status"],"processing_time_s":proc_t,"timestamp":ts
    })
    return out


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 12 — COMPARE MODE
# ══════════════════════════════════════════════════════════════════════════════

def build_comparison_output(doc_id, fp, results, ts):
    comp = {"document_id":doc_id,"file_name":fp.name,"timestamp":ts,"comparison":{}}
    best, best_s = None, -1
    for method, r in results.items():
        if r["success"]:
            q = r.get("quality",{})
            s = q.get("score",0)
            comp["comparison"][method] = {
                "success":True,"quality_score":s,"keyword_hits":q.get("keyword_hits",0),
                "assessment":q.get("assessment","?"),"headings_count":q.get("headings_count",0),
                "tables_count":q.get("tables_count",0),"garble_ratio":q.get("garble_ratio",0),
                "token_count":r.get("token_count",0),"processing_time_s":r.get("processing_time_s",0),
                "preview":r.get("markdown_text","")[:300]
            }
            if s > best_s:
                best_s, best = s, method
        else:
            comp["comparison"][method] = {"success":False,"reason":r.get("reason","?")}
    comp["recommended_method"] = best
    comp["recommended_reason"]  = f"{best} scored {best_s:.2f}" if best else "all failed"
    return comp


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 13 — SAVE OUTPUT
# ══════════════════════════════════════════════════════════════════════════════

def save_output(result: dict, fp: Path, compare_mode: bool = False) -> Path:
    stem   = fp.stem
    suf    = "_compare" if compare_mode else "_ocr"
    jpath  = OUTPUT_DIR / f"{stem}{suf}.json"
    with open(jpath,"w",encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    log.info(f"Saved: {jpath}")
    if not compare_mode and result.get("markdown_text"):
        ppath = OUTPUT_DIR / f"{stem}_preview.txt"
        with open(ppath,"w",encoding="utf-8") as f:
            f.write(f"TraceConnect OCR Preview — v1.1.0\n{'='*60}\n")
            for k,v in [("File",result.get("file_name")),("Method",result.get("extraction_method","?").upper()),
                        ("Quality",f"{result.get('quality_tier','?').upper()} ({result.get('confidence_score',0):.2f})"),
                        ("Language",result.get("language_detected","?")),
                        ("Pages",result.get("total_pages",1)),
                        ("Tokens",f"{result.get('token_count',0):,} (raw {result.get('raw_token_count',0):,})"),
                        ("Compressed",f"{result.get('compression_pct',0):.1f}%"),
                        ("Intents",", ".join(result.get("intents_detected",[])) or "none"),
                        ("Timestamp",result.get("extraction_timestamp",""))]:
                f.write(f"{k:<12}: {v}\n")
            f.write(f"{'='*60}\n\n{result['markdown_text']}")
        log.info(f"Preview: {ppath}")
    return jpath


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 14 — SUMMARY PRINT
# ══════════════════════════════════════════════════════════════════════════════

def print_summary(result: dict, compare_mode: bool = False):
    print(f"\n{'='*60}\n  TRACECONNECT OCR v1.1.0 — SUMMARY\n{'='*60}")
    if compare_mode:
        print(f"  File: {result.get('file_name')}")
        print(f"\n  {'Method':<15} {'OK':<6} {'Score':<8} {'KW':<6} {'Tokens':<10} Time")
        print(f"  {'-'*55}")
        for m, d in result.get("comparison",{}).items():
            if d.get("success"):
                print(f"  {m:<15} YES    {d.get('quality_score',0):.2f}    {d.get('keyword_hits',0):<6}"
                      f"{d.get('token_count',0):<10} {d.get('processing_time_s',0):.1f}s")
            else:
                print(f"  {m:<15} NO     {d.get('reason','')}")
        print(f"\n  RECOMMENDED: {(result.get('recommended_method') or 'none').upper()}")
    else:
        cached = " [CACHED]" if result.get("_from_cache") else ""
        print(f"  File      : {result.get('file_name')}{cached}")
        print(f"  Status    : {result.get('status','?').upper()}")
        print(f"  Method    : {result.get('extraction_method','none').upper()}")
        print(f"  Quality   : {result.get('quality_tier','?').upper()} ({result.get('confidence_score',0):.2f})")
        print(f"  Language  : {result.get('language_detected','?').upper()}")
        print(f"  Pages     : {result.get('total_pages',1)}")
        print(f"  Tokens    : {result.get('token_count',0):,} (raw {result.get('raw_token_count',0):,})")
        print(f"  Compressed: {result.get('compression_pct',0):.1f}%")
        if result.get("intents_detected"):
            print(f"  Intents   : {', '.join(result['intents_detected'])}")
        if result.get("bm_translations_count",0) > 0:
            print(f"  BM terms  : {result['bm_translations_count']} translated")
        for flag in result.get("quality_flags",[]):
            print(f"  ⚠  {flag}")
        for fb in result.get("extraction_fallbacks",[]):
            print(f"  →  {fb}")
    print(f"{'='*60}\n")


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 15 — BATCH (multiprocessing)  [H5]
# ══════════════════════════════════════════════════════════════════════════════

def _worker(args):
    fp, cm = args
    try:
        r = run_pipeline(Path(fp), compare_mode=cm)
        save_output(r, Path(fp), compare_mode=cm)
        return {"file":Path(fp).name,"status":r.get("status","?"),
                "method":r.get("extraction_method","?"),"tier":r.get("quality_tier","?"),
                "tokens":r.get("token_count",0),"pages":r.get("total_pages",1)}
    except Exception as e:
        return {"file":Path(fp).name,"status":"error","error":str(e)}

def process_folder(folder_path: Path, compare_mode: bool = False, workers: int = 4):
    """[H5] Parallel batch processing — was sequential, now uses ProcessPoolExecutor."""
    fp = Path(folder_path)
    if not fp.exists():
        log.error(f"Folder not found: {fp}"); return
    files = [f for f in fp.iterdir() if f.is_file() and f.suffix.lower() in SUPPORTED_TYPES]
    if not files:
        log.warning("No supported files found"); return
    log.info(f"Batch: {len(files)} files · {workers} workers")
    args = [(str(f), compare_mode) for f in files]
    summary = []
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(_worker, a):a for a in args}
        for i, fut in enumerate(as_completed(futs), 1):
            r = fut.result()
            summary.append(r)
            log.info(f"[{i}/{len(files)}] {r['file']} → {r.get('status','?')} ({r.get('method','?')})")
    print(f"\n{'='*70}\n  BATCH COMPLETE\n{'='*70}")
    print(f"  {'File':<30} {'Status':<10} {'Method':<15} {'Tier':<8} {'Pages':<6} Tokens")
    print(f"  {'-'*65}")
    for r in summary:
        print(f"  {r['file'][:30]:<30} {r.get('status','?'):<10} {r.get('method','?'):<15} "
              f"{r.get('tier','?'):<8} {r.get('pages',1):<6} {r.get('tokens',0):,}")
    print(f"{'='*70}\n")


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 16 — RETRY FAILED  [C3]
# ══════════════════════════════════════════════════════════════════════════════

def retry_failed():
    """[C3] Reprocess everything in failed_queue.json."""
    q = load_failed_queue()
    if not q:
        print("No failed documents in queue."); return
    print(f"Retrying {len(q)} document(s)...")
    still = []
    for entry in q:
        fp = Path(entry["file"])
        if not fp.exists():
            log.warning(f"File gone: {fp}"); continue
        entry["retry_count"] = entry.get("retry_count",0) + 1
        r = run_pipeline(fp)
        if r.get("status") == "ready":
            save_output(r, fp)
            log.info(f"RETRY OK: {fp.name}")
        else:
            log.warning(f"RETRY FAILED: {fp.name}")
            still.append(entry)
    save_failed_queue(still)
    print(f"Done. Still failing: {len(still)}")


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 17 — GROUND TRUTH VALIDATION  [M4]
# ══════════════════════════════════════════════════════════════════════════════

def validate_against_ground_truth(test_dir: Path, truth_dir: Path):
    """
    [M4, upgraded] Compare pipeline's ACTUAL extracted fields against
    manually verified expected values — not just a loose substring check
    on the raw text (that was the old behaviour, kept as a secondary
    check below since it's still useful for catching OCR quality issues
    separately from field-extraction issues).

    Create expected files like: test_docs/ground_truth/rfi_023_expected.json
    {
      "canonical_document_type": "Request for Information",
      "document_reference": "RFI-023",
      "revision_number": "B",
      "document_date": "2026-07-20",
      "key_phrases": ["beam specification", "Level 11-14"]
    }
    Use null (not omission) for a field that should genuinely extract as
    None — e.g. a document type with no revision of its own. Omitting a
    key entirely means "don't check this field," which is different from
    "the correct answer is nothing."
    """
    td, gd = Path(test_dir), Path(truth_dir)
    if not gd.exists():
        print(f"Ground truth folder not found: {gd}"); return
    files = [f for f in td.iterdir() if f.is_file() and f.suffix.lower() in SUPPORTED_TYPES]

    FIELDS = ["canonical_document_type", "document_reference", "revision_number", "document_date"]
    field_correct = {f: 0 for f in FIELDS}
    field_checked = {f: 0 for f in FIELDS}
    per_doc_results = []

    print(f"\n{'='*70}\n  GROUND TRUTH VALIDATION — field-level accuracy\n{'='*70}")
    for fp in files:
        tp = gd / f"{fp.stem}_expected.json"
        if not tp.exists():
            print(f"  SKIP  {fp.name}  (no {tp.name})")
            continue
        try:
            expected = json.loads(tp.read_text(encoding="utf-8"))
        except Exception as e:
            print(f"  ERROR {fp.name}  (bad JSON: {e})")
            continue

        if not expected.get("_reviewed", False):
            print(f"  SKIP  {fp.name}  (ground truth not yet reviewed — "
                  f"see _reviewed flag in {tp.name})")
            continue

        r = run_pipeline(fp)
        mismatches = []
        for field in FIELDS:
            if field not in expected:
                continue   # key omitted entirely = don't check this field
            field_checked[field] += 1
            exp_val = expected[field]
            got_val = r.get(field)
            norm = lambda v: (v or "").strip().upper() if isinstance(v, str) else v
            if norm(exp_val) == norm(got_val):
                field_correct[field] += 1
            else:
                mismatches.append(f"{field}: expected {exp_val!r}, got {got_val!r}")

        # Secondary check: does the OCR'd text at least contain expected phrases
        text = r.get("markdown_text", "").lower()
        for phrase in expected.get("key_phrases", []):
            if phrase.lower() not in text:
                mismatches.append(f"key phrase not found in OCR text: {phrase!r}")

        status = "PASS" if not mismatches else "FAIL"
        print(f"  {status}  {fp.name}")
        for m in mismatches:
            print(f"        x {m}")
        per_doc_results.append((fp.name, status, len(mismatches)))

    print(f"\n{'-'*70}\n  PER-FIELD ACCURACY\n{'-'*70}")
    for field in FIELDS:
        checked = field_checked[field]
        if checked == 0:
            print(f"  {field:28s}: no ground truth data for this field yet")
            continue
        correct = field_correct[field]
        pct = round(correct / checked * 100, 1)
        bar = "#" * int(pct / 5) + "." * (20 - int(pct / 5))
        print(f"  {field:28s}: {correct}/{checked}  ({pct}%)  [{bar}]")

    total_docs = len(per_doc_results)
    fully_passed = sum(1 for _, s, _ in per_doc_results if s == "PASS")
    print(f"\n  Documents fully correct: {fully_passed}/{total_docs}")
    print(f"{'='*70}\n")


# ══════════════════════════════════════════════════════════════════════════════
#  SECTION 18 — CLI
# ══════════════════════════════════════════════════════════════════════════════

def main():
    p = argparse.ArgumentParser(description="TraceConnect OCR Pipeline v1.1.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python ocr_pipeline.py --file "rfi_023.pdf"
  python ocr_pipeline.py --file "rfi_023.pdf" --compare
  python ocr_pipeline.py --folder "test_docs/"
  python ocr_pipeline.py --folder "test_docs/" --workers 8
  python ocr_pipeline.py --retry-failed
  python ocr_pipeline.py --validate test_docs/ test_docs/ground_truth/
""")
    p.add_argument("--file",         type=str)
    p.add_argument("--folder",       type=str)
    p.add_argument("--compare",      action="store_true")
    p.add_argument("--stats",        action="store_true")
    p.add_argument("--workers",      type=int, default=4)
    p.add_argument("--retry-failed", action="store_true", dest="retry_failed")
    p.add_argument("--validate",     nargs=2, metavar=("TEST","TRUTH"))
    args = p.parse_args()

    if args.retry_failed:
        retry_failed()
    elif args.validate:
        validate_against_ground_truth(Path(args.validate[0]), Path(args.validate[1]))
    elif args.folder:
        process_folder(Path(args.folder), compare_mode=args.compare, workers=args.workers)
    elif args.file:
        fp = Path(args.file)
        r  = run_pipeline(fp, compare_mode=args.compare)
        print_summary(r, compare_mode=args.compare)
        if not args.stats:
            saved = save_output(r, fp, compare_mode=args.compare)
            print(f"Saved: {saved}\n")
    else:
        p.print_help()
        sys.exit(1)

if __name__ == "__main__":
    main()
