# TraceConnect Engineering Wiki — The Spinal Layer Architecture

*Internal reference. Written against the actual `app.py` / `engine_bridge.py` /
`data_vault.py` stack, not a generic tutorial — every code reference below
points at a real line in this repo.*

---

## 1. Separation of Concerns (the whole reason there are 3 files, not 1)

**The principle:** a module should have one reason to change. If a bug in your
OCR quality scoring and a bug in your button layout can both force you to
edit the same file, that file has more than one reason to change, and it will
keep getting harder to modify safely as it grows.

**How it's structured here:** three files, three unrelated reasons to change:

| Layer | File | Changes when… |
|---|---|---|
| Frontend | `app.py` | You want the UI to look or flow differently |
| Middleware | `engine_bridge.py` | The data contract between UI and engine changes |
| Backend | `data_vault.py` | Storage strategy or retry policy changes |

**Why this isn't just tidiness — it's what makes the migration path real.**
Rev02 already specifies the production target: TypeScript frontend + Python
API. Because `app.py` only ever talks to `engine_bridge.dispatch_ocr()` and
never touches `data_vault` or `ocr_pipeline` directly, that function is
*already* shaped like an API route handler. When you build the real FastAPI
backend, `dispatch_ocr()`'s logic moves over almost unchanged — you're
swapping the caller (Streamlit → HTTP request), not rewriting the contract.
If `app.py` had called `ocr_pipeline.run_pipeline()` directly, you'd be
rewriting the whole thing from scratch instead of relocating it.

**The failure mode you're avoiding:** the classic "God file" — one script
that renders UI, runs OCR, and writes to disk all in the same function. It
works fine for a demo. It becomes unmaintainable at the second engineer,
because nobody can change one behavior without risking the other two.

---

## 2. State Management — `st.session_state` (`app.py`, `init_state()`)

**The technical learning:** Streamlit's execution model is fundamentally
different from a traditional web app. On *every* user interaction — a click,
a text input, a file drop — Streamlit doesn't call a specific event handler.
It **reruns the entire Python script from top to bottom.** Every local
variable you declared gets recreated from scratch. Without an external place
to persist values across that rerun, your app would have permanent amnesia:
upload a file, click "Process," and the rerun would forget the upload ever
happened.

**How the code executes this, step by step:**
```python
def init_state():
    defaults = {
        "session_id": str(uuid.uuid4()),
        "is_processing": False,
        "last_result": None,
        ...
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val
```
`st.session_state` is a dict-like object Streamlit keeps alive **outside**
the script's normal variable scope, tied to one browser tab's session on the
server. The `if key not in st.session_state` guard is doing real work: it
means this function only *sets* a default the first time it's called for
that session. On every subsequent rerun (which happens on every click), the
existing values are left untouched — that's what makes `is_processing`
actually remember it's `True` across the rerun that happens *while* the spinner
is showing.

**The direct payoff — race-condition prevention:** look at the process
button:
```python
process_clicked = st.button("🔍 Process Document",
    disabled=st.session_state.is_processing or uploaded is None, ...)
```
Because `is_processing` survives the rerun, the button is provably disabled
during the entire OCR call — not just visually greyed out while secretly
still clickable. A spam-click during processing reruns the script, sees
`is_processing == True` from the *previous* run, and the button render is
disabled before the user's second click can even register as a new dispatch.

---

## 3. Idempotency — two different implementations, worth telling apart

**The technical learning:** an operation is idempotent if doing it once and
doing it five times produce the same end state. This matters anywhere a
request might get retried, resent, or double-clicked — which, per the spec,
is exactly the failure mode you're guarding against.

There are **two separate idempotency mechanisms** in this stack, solving
different problems:

**(a) Content-level idempotency — `ocr_pipeline.py`'s fingerprint cache.**
Every file gets hashed (`get_file_fingerprint`); if that exact content was
already processed, `run_pipeline()` returns the cached result instantly
instead of re-running OCR. This is idempotent on **file content** — upload
the same PDF twice, from two different sessions, on two different days, and
you get the same document_id back both times, no duplicate OCR spend.

**(b) Request-level idempotency — the correction-logging guard.**
```python
def log_correction(document_id, field, auto_value, corrected_value, session_id):
    if str(auto_value) == str(corrected_value):
        return True  # no real correction happened, skip the write entirely
```
This isn't about duplicate *files* — it's about not polluting your training
data with "corrections" that didn't actually correct anything (a user who
opens the form and resubmits without changing a field). Skipping the write
here isn't an optimization, it's a data-quality decision: every row in
`ocr_corrections.json` should represent a real human judgment.

---

## 4. Data Serialization & Contracts — Pydantic (`engine_bridge.py`)

**The technical learning:** "serialization" is turning an in-memory Python
object into a portable form (here, JSON) and back. The dangerous part isn't
the conversion — it's that Python's dynamic typing means nothing stops a
`None`, a wrong type, or a missing key from silently flowing from one layer
to the next until it explodes three function calls later with a confusing
`KeyError` deep inside the OCR engine.

**How the code executes this:**
```python
class OCRRequest(BaseModel):
    file_name: str
    file_bytes: bytes
    session_id: str = Field(..., min_length=1)

    @field_validator("file_name")
    @classmethod
    def suffix_must_be_supported(cls, v: str) -> str:
        ...
```
The moment `OCRRequest(file_name=..., file_bytes=..., session_id=...)` is
constructed, Pydantic runs every validator. If anything's wrong, it raises
`ValidationError` *at the boundary*, with a structured, specific message —
"Unsupported file type '.exe'" — instead of letting bad data travel deeper
into the system where the eventual error would be much harder to trace back
to its real cause.

The same idea runs in the other direction with `OCRResponse`: `app.py` is
**structurally guaranteed** never to receive a response missing a field it
expects, because the response is validated against the `OCRResponse` schema
before it's ever handed back. If `ocr_pipeline.py`'s output shape ever
drifts, you get a loud, specific `ValidationError` in the logs — not a
silent `None.confidence_score` crash inside the UI.

---

## 5. Race Conditions & Atomic Writes (`data_vault.py`)

**The technical learning:** a race condition is a bug that only exists
because of *timing* — two operations that would each work fine alone corrupt
each other when they happen close together. The classic case here: two
sessions finish OCR within milliseconds of each other, both read
`ocr_storage.json`, both append their record in memory, both write the file
back — and whichever write finishes last **silently overwrites** the other's
record. No error, no crash, just quietly missing data.

**How the code prevents it — two mechanisms working together:**

1. **`FileLock`** (`filelock` library) — a cross-process advisory lock
   backed by a `.lock` file on disk. Only one writer can hold it; everyone
   else blocks until it's free. This serializes every writer regardless of
   whether they're different browser sessions, different threads, or (if you
   later run multiple worker processes) different OS processes entirely.

2. **Write-to-temp-then-atomic-rename:**
   ```python
   fd, tmp_path = tempfile.mkstemp(dir=str(BASE_DIR), suffix=".tmp")
   with open(fd, "w") as f:
       json.dump(records, f, ...)
   Path(tmp_path).replace(path)   # atomic on POSIX + modern Windows
   ```
   We never modify `ocr_storage.json` in place. We write a **complete** new
   file under a temp name, then `Path.replace()` — which the OS guarantees
   is an atomic rename. There's no instant where the file is half-written.
   Kill the process mid-write and a reader either sees the fully-old file or
   the fully-new file — never a truncated, corrupt JSON file.

**Verified, not assumed:** during setup, this was stress-tested with 50
concurrent threads writing simultaneously — all 50 records persisted intact
with no lost updates. That's the actual claim being made here, tested, not
just asserted in a docstring.

---

## 6. Fault Tolerance & Retry Logic (`data_vault.py`, `_execute_with_retry`)

**The technical learning:** a *transient* failure (a flaky network call, a
momentary disk hiccup) is fundamentally different from a *permanent* one (a
corrupt file, an unsupported format). Retrying a permanent failure just
wastes time and delays the error message the user actually needs. The trick
is telling them apart.

**How the code does it:**
```python
if "error" in result:
    return result   # not transient — don't retry, fail fast
```
Bad-file-type or missing-file errors are returned immediately, no retry.
Only an unexpected *exception* — something crashing before it even gets to
classify the failure — triggers the retry loop, with exponential-ish
backoff (`RETRY_BACKOFF_S * attempt`).

This wasn't theoretical during development: `ocr_pipeline.py`'s Docling
stage tries to fetch a layout model from Hugging Face on first use. In a
network-restricted environment that call failed outright — and the
*engine's own* internal fallback chain (MarkItDown → Docling → Tesseract)
correctly routed around it. This retry wrapper protects the narrower case
one level up: the whole call throwing before the engine's internal fallback
logic even gets a chance to run.

---

## 7. Cursor & Replit Benchmark — heavy local state without freezing the UI

*(Note: this describes publicly-discussed architectural patterns common to
this category of tool, not proprietary internals of either product.)*

Tools like Cursor and Replit face a version of your exact problem: a large,
continuously-updating stream of data (a file tree, streaming AI output, a
running process's stdout) has to update the UI *without* blocking the thread
the user is typing in. Two patterns they lean on, that map directly onto
choices in this codebase:

- **Off-main-thread execution for heavy work.** Long operations run off the
  UI's responsiveness path, with the UI subscribing to progress/results
  rather than blocking on them. `engine_bridge.py`'s use of
  `asyncio.to_thread()` to run OCR off Streamlit's main script-execution path
  is a small-scale version of this same idea — the heavy call doesn't block
  the interpreter's ability to eventually handle the timeout logic wrapped
  around it.
- **Incremental, chunked rendering instead of one big blocking update.**
  Rather than waiting for an entire response before showing anything,
  editors like these stream tokens/output as they arrive so the UI stays
  perceptibly alive. Your app doesn't do this yet — `st.spinner` is an
  honest "please wait" rather than a progressive reveal — but if OCR
  processing time becomes a real friction point with alpha testers, this is
  the natural next optimization: stream per-page results as `split_into_pages()`
  produces them, rather than waiting for the whole document.

**Honest caveat, because overselling this would teach the wrong lesson:**
Streamlit's rerun-the-whole-script model is not a persistent event loop the
way Cursor's or Replit's client-server architecture is. `asyncio.to_thread()`
here gets you real thread offload and a real timeout guard — it does not get
you the kind of fine-grained, always-on concurrency those tools run. That's
exactly why `dispatch_ocr()` is deliberately shaped like a future FastAPI
route: the honest fix for "Streamlit's concurrency model is limited" is
eventually running behind a real async server, not pretending Streamlit
already behaves like one.

---

## 8. Scale AI Benchmark — schema enforcement and safe telemetry at volume

*(Same caveat: describing well-known data-engineering patterns for this
problem class, not Scale AI's actual internal codebase.)*

Any company processing large volumes of externally-sourced data — labeled
training data, in Scale AI's case; scanned construction documents, in
yours — converges on the same handful of practices, because the failure
modes are the same at any real volume:

- **Schema enforcement at the ingestion boundary, not deep inside the
  pipeline.** Bad data should fail loudly at the door, with a specific
  reason, rather than corrupting something three stages downstream where
  it's much harder to trace back. This is precisely what `OCRRequest`'s
  Pydantic validators do — reject an unsupported file type before a single
  CPU cycle of OCR runs on it.
- **Append-only, immutable event logs for auditability.** You don't edit a
  historical record in place; you append a new event and derive current
  state from the full history. `_atomic_append()` writing to
  `ocr_storage.json` is a minimal version of this — every OCR execution is a
  permanent, ordered fact, not a row that gets silently overwritten.
- **Idempotent ingestion keys so retries can't create duplicate work.**
  Content-addressed identifiers (a hash of the actual data, not a
  user-supplied name) let you safely retry an upload without creating two
  copies of the same underlying work. `ocr_pipeline.py`'s fingerprint-based
  duplicate detection is exactly this pattern, applied to documents instead
  of labeling tasks.

The throughline across both benchmarks: **the specific technology differs by
company (their infra is built for millions of concurrent labeling tasks;
yours is built for two founders and a handful of alpha testers), but the
underlying principles — validate at the boundary, make writes atomic and
auditable, make retries safe — are scale-invariant.** You're not doing a toy
version of these ideas to be replaced later; you're doing the same ideas at
the size that's actually correct for where you are today.

---

## 9. What this stack deliberately does NOT do yet — and why that's correct

- **No database.** `ocr_storage.json` is intentionally simple. Rev02 already
  names PostgreSQL as the target; jumping there before you have real alpha
  data to inform the schema would be premature infrastructure — a named risk
  in your own register (OS-R03: "Excessive RAG/vector infrastructure").
- **No auth, no multi-tenant isolation.** Real requirements once you have
  external users with confidential documents, but they're Stage 1 work
  (per Rev02's roadmap) and would slow down getting an alpha in front of
  testers this week for zero validation value at "5 friendly testers" scale.
- **No true async web server.** As covered above — Streamlit's model is a
  deliberate, honest trade for speed-to-alpha, not a permanent architecture.

Building these now, before real usage data exists to justify the specific
shape they should take, is exactly the trap Rev02's own audit calls out:
"premature stack lock-in."
