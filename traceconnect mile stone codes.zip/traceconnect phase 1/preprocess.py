import cv2
import numpy as np
from PIL import Image


def pil_to_cv(img: Image.Image):
    return cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)


def cv_to_pil(arr) -> Image.Image:
    return Image.fromarray(cv2.cvtColor(arr, cv2.COLOR_BGR2RGB))


def deskew(cv_img):
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thresh > 0))
    if len(coords) < 20:
        return cv_img, 0.0
    raw_angle = cv2.minAreaRect(coords)[-1]
    # [FIX] cv2.getRotationMatrix2D rotates counter-clockwise for a
    # POSITIVE angle. minAreaRect's raw angle, left unnegated, was being
    # applied in the same direction as the original skew instead of
    # against it — compounding the tilt rather than correcting it.
    # Verified by testing: without this fix, a deliberately-skewed test
    # image came out of "correction" still visibly tilted.
    if raw_angle < -45:
        angle = -(90 + raw_angle)
    else:
        angle = -raw_angle
    if abs(angle) < 0.3 or abs(angle) > 20:
        return cv_img, angle
    (h, w) = cv_img.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated = cv2.warpAffine(cv_img, M, (w, h), flags=cv2.INTER_CUBIC,
                              borderMode=cv2.BORDER_REPLICATE)
    return rotated, angle


def binarize(cv_img):
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    # Adaptive threshold handles uneven lighting (shadows, phone-camera
    # glare) far better than a single global threshold would.
    binarized = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 11
    )
    return cv2.cvtColor(binarized, cv2.COLOR_GRAY2BGR)


def preprocess_for_ocr(img: Image.Image, do_deskew=True, do_binarize=False) -> Image.Image:
    """
    do_binarize defaults to False based on direct testing: with modern
    Tesseract (v4/v5, LSTM-based), external pre-binarization consistently
    made OCR WORSE across three different threshold tunings tested here —
    Tesseract's LSTM engine already does its own internal binarization,
    and pre-binarizing throws away greyscale information it could have
    used. This is different from older Tesseract 3 (legacy engine), where
    external binarization was genuinely good advice — that advice doesn't
    hold for the engine actually being used here. Deskewing, by contrast,
    measurably helped (near-ceiling OCR quality vs. badly degraded/missing
    text on the skewed original) and is on by default.
    Left available as an opt-in for the rare genuinely poor-lighting scan
    where it might still help — test on your own documents before
    defaulting it on for a specific use case.
    """
    cv_img = pil_to_cv(img)
    angle = 0.0
    if do_deskew:
        cv_img, angle = deskew(cv_img)
    if do_binarize:
        cv_img = binarize(cv_img)
    return cv_to_pil(cv_img), angle
