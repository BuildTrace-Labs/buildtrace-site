"""
build_ground_truth_template.py — fast-start tool for building your 10-50
document validation set.

Runs the pipeline once per document and writes a *_expected.json skeleton
pre-filled with what it currently predicted — so you're reviewing and
correcting, not typing every field from a blank page.

CRITICAL: files this generates are marked "_reviewed": false. The
validator (ocr_pipeline.py --validate) will refuse to count a file toward
accuracy until you've opened it, checked/corrected each field against the
actual document, and flipped that to true. Skipping this step would mean
comparing the pipeline's predictions to themselves — a meaningless 100%.

Usage:
    python3 build_ground_truth_template.py test_docs/
    (writes test_docs/ground_truth/<stem>_expected.json for every
     supported file in test_docs/ that doesn't already have one)
"""
import sys
import json
from pathlib import Path

import ocr_pipeline as ocr


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 build_ground_truth_template.py <folder>")
        sys.exit(1)

    folder = Path(sys.argv[1])
    gt_dir = folder / "ground_truth"
    gt_dir.mkdir(exist_ok=True)

    files = [f for f in folder.iterdir()
             if f.is_file() and f.suffix.lower() in ocr.SUPPORTED_TYPES]

    if not files:
        print(f"No supported documents found in {folder}")
        return

    created, skipped = 0, 0
    for fp in files:
        out_path = gt_dir / f"{fp.stem}_expected.json"
        if out_path.exists():
            skipped += 1
            continue

        print(f"Processing: {fp.name}")
        r = ocr.run_pipeline(fp)

        template = {
            "_reviewed": False,
            "_instructions": "Open the actual document, check each field "
                              "below against it, correct anything wrong, "
                              "then set _reviewed to true. Unreviewed "
                              "files are ignored by --validate.",
            "canonical_document_type": r.get("canonical_document_type"),
            "document_reference": r.get("document_reference"),
            "revision_number": r.get("revision_number"),
            "document_date": r.get("document_date"),
            "key_phrases": [],
        }
        out_path.write_text(json.dumps(template, indent=2, ensure_ascii=False),
                             encoding="utf-8")
        print(f"  -> {out_path}  (predicted: type={template['canonical_document_type']!r}, "
              f"ref={template['document_reference']!r}, "
              f"rev={template['revision_number']!r}, "
              f"date={template['document_date']!r})")
        created += 1

    print(f"\nCreated {created} template(s), skipped {skipped} (already existed).")
    print(f"\nNext step: open each file in {gt_dir}/, verify against the real")
    print(f"document, fix anything wrong, set \"_reviewed\": true, then run:")
    print(f"\n    python3 ocr_pipeline.py --validate {folder} {gt_dir}\n")


if __name__ == "__main__":
    main()
