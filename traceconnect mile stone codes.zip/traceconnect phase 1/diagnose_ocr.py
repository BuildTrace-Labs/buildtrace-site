"""
diagnose_ocr.py — find out exactly WHERE and WHY a document is failing,
one stage at a time, without printing the document's actual content.

Usage:
    python3 diagnose_ocr.py "path/to/your/file.pdf"

Safe to run on real/confidential documents — by default this only prints
character counts, quality flags, and error messages, never the extracted
text itself. Pass --show-text if you explicitly want to see the extracted
content too (e.g. to eyeball whether it's garbled).
"""
import sys
import traceback
from pathlib import Path

import ocr_pipeline as ocr


def summarize(label: str, result: dict, show_text: bool):
    print(f"\n{'='*60}")
    print(f"  {label}")
    print(f"{'='*60}")
    if result is None:
        print("  -> returned None (unexpected)")
        return

    success = result.get("success", False)
    print(f"  success: {success}")

    if not success:
        print(f"  reason  : {result.get('reason', '(no reason given)')}")
        if "error" in result:
            print(f"  error   : {result['error']}")
        if "quality_score" in result:
            print(f"  quality_score at failure: {result['quality_score']}")
        if "raw_attempt" in result:
            preview = result["raw_attempt"][:200]
            print(f"  raw_attempt length: {len(result['raw_attempt'])} chars"
                  + (f"\n  raw_attempt preview: {preview!r}" if show_text else ""))
        return

    text = result.get("markdown_text", "")
    quality = result.get("quality", {})
    print(f"  method              : {result.get('method')}")
    print(f"  characters extracted: {len(text)}")
    print(f"  quality score       : {quality.get('score')}")
    print(f"  quality assessment  : {quality.get('assessment', '(n/a — passed threshold)')}")
    print(f"  keyword_hits        : {quality.get('keyword_hits')}")
    print(f"  garble_ratio        : {quality.get('garble_ratio')}")
    print(f"  processing_time_s   : {result.get('processing_time_s')}")
    if len(text.strip()) == 0:
        print("  ⚠ Passed quality gate but text is empty — inspect ocr_pipeline.py's threshold logic")
    if show_text:
        print(f"\n  --- extracted text (first 2000 chars) ---\n{text[:2000]}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 diagnose_ocr.py <path-to-file> [--show-text]")
        sys.exit(1)

    file_path = Path(sys.argv[1])
    show_text = "--show-text" in sys.argv

    if not file_path.exists():
        print(f"File not found: {file_path}")
        sys.exit(1)

    print(f"Diagnosing: {file_path.name}  ({file_path.stat().st_size / 1024:.1f} KB)")
    print(f"Extension : {file_path.suffix}")

    # ── Stage 0: MarkItDown ──────────────────────────────────────────
    try:
        r = ocr.extract_with_markitdown(file_path)
        summarize("STAGE 0 — MarkItDown (native text extraction)", r, show_text)
    except Exception as e:
        print(f"\nSTAGE 0 — MarkItDown: RAISED AN EXCEPTION")
        print(f"  {type(e).__name__}: {e}")
        traceback.print_exc(limit=3)

    # ── Stage 1: Docling ─────────────────────────────────────────────
    try:
        r = ocr.extract_with_docling(file_path)
        summarize("STAGE 1 — Docling (layout-aware fallback)", r, show_text)
    except Exception as e:
        print(f"\nSTAGE 1 — Docling: RAISED AN EXCEPTION")
        print(f"  {type(e).__name__}: {e}")
        print("  (Common cause: no network access to huggingface.co for the layout model)")
        traceback.print_exc(limit=3)

    # ── Stage 2: Tesseract ───────────────────────────────────────────
    try:
        r = ocr.extract_with_tesseract(file_path)
        summarize("STAGE 2 — Tesseract (OCR on rendered pages)", r, show_text)
    except Exception as e:
        print(f"\nSTAGE 2 — Tesseract: RAISED AN EXCEPTION")
        print(f"  {type(e).__name__}: {e}")
        print("  (Common cause: tesseract binary not on PATH, or PDF has 0 renderable pages)")
        traceback.print_exc(limit=3)

    # ── Also check: is this even a valid, readable PDF? ─────────────
    if file_path.suffix.lower() == ".pdf":
        print(f"\n{'='*60}")
        print("  PDF STRUCTURE CHECK")
        print(f"{'='*60}")
        try:
            import fitz  # pymupdf
            doc = fitz.open(str(file_path))
            print(f"  Pages: {doc.page_count}")
            print(f"  Encrypted: {doc.is_encrypted}")
            for i, page in enumerate(doc):
                native_text_len = len(page.get_text().strip())
                img_count = len(page.get_images())
                print(f"  Page {i+1}: {native_text_len} chars of native text, {img_count} embedded image(s)")
                if i >= 4:
                    print(f"  ... ({doc.page_count - 5} more pages not shown)")
                    break
            doc.close()
        except Exception as e:
            print(f"  Could not open with pymupdf: {type(e).__name__}: {e}")
            print("  This itself is diagnostic — may indicate a corrupt or non-standard PDF")

    print(f"\n{'='*60}")
    print("  DONE — paste this whole output back to diagnose the failure")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
