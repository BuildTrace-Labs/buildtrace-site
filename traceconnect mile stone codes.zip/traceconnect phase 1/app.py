"""
app.py — FRONTEND (THE UX & STATE LAYER)
==========================================
RULE FOR THIS FILE: if a line of code touches the OCR engine, opens
ocr_storage.json, or does anything heavier than formatting a string for
display, it does not belong here. This file's only two jobs are:
  1. Render the UI
  2. Hold st.session_state and decide, based on that state, what to render

Every actual OCR call and every write to disk happens through
engine_bridge.py's dispatch_ocr() / dispatch_correction(). This file
never imports data_vault or ocr_pipeline directly — that boundary is
enforced by convention here (Python won't stop you), but breaking it
is exactly the kind of shortcut that makes a codebase impossible to
scale past two people.
"""

from __future__ import annotations

import uuid
import streamlit as st

import engine_bridge


# ──────────────────────────────────────────────────────────────────────────
# Page config + custom CSS
# ──────────────────────────────────────────────────────────────────────────
st.set_page_config(page_title="TraceConnect — Document Intelligence",
                    page_icon="📐", layout="wide", initial_sidebar_state="expanded")

CUSTOM_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&display=swap');

:root{
  --ink:#1B2A4A;        /* blueprint navy — headers, body text */
  --ink-soft:#4A5A7A;
  --paper:#EFEBDF;       /* drafting-paper background — deliberately warm, not near-white */
  --card:#FFFFFF;
  --line:#D6D0BE;
  --accent:#E8622C;      /* safety-orange — primary actions, redline markup */
  --accent-soft:#FBE7DB;
  --green:#3F7D5C; --green-soft:#E7F1EC;
  --amber:#B8862E; --amber-soft:#FBF1DF;
  --red:#B23A2E;   --red-soft:#FBE7E4;
}

html, body { font-family:'Inter', sans-serif; }

/* [FIX] The old selector [class*="css"] targeted a Streamlit DOM pattern
   that no longer exists in current versions — it silently matched almost
   nothing, so native Streamlit text (titles, sidebar, labels) fell back to
   Streamlit's own theme default. If the browser prefers dark mode, that
   default resolves to light gray — invisible against our light background.
   These selectors target the actual current Streamlit structure. */
.stApp, .stApp p, .stApp span, .stApp label, .stApp li,
.stMarkdown, [data-testid="stMarkdownContainer"],
[data-testid="stMarkdownContainer"] p,
h1, h2, h3, h4, h5, h6 {
  color: var(--ink) !important;
  font-family: 'Inter', sans-serif;
}
[data-testid="stSidebar"] * { color: var(--ink) !important; }
[data-testid="stSidebar"] { background:var(--card); border-right:2px solid var(--ink); }

.stMarkdown h1, .stMarkdown h2, .stMarkdown h3 { font-family:'Space Grotesk', sans-serif !important; letter-spacing:-0.01em; }

.stApp {
  background-color: var(--paper);
  background-image:
    linear-gradient(rgba(27,42,74,0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(27,42,74,0.05) 1px, transparent 1px);
  background-size: 28px 28px;
}

/* Header block */
.tc-header { padding: 14px 0 18px 0; border-bottom:3px solid var(--ink); margin-bottom:28px; }
.tc-eyebrow { font-size:12px; letter-spacing:0.14em; text-transform:uppercase; color:var(--accent); font-weight:600; }
.tc-title { font-family:'Space Grotesk',sans-serif; font-size:30px; font-weight:700; margin:2px 0 4px 0; color:var(--ink); }
.tc-sub { color:var(--ink-soft); font-size:14.5px; }

/* Drop zone styling — technical-drawing revision-cloud feel */
[data-testid="stFileUploaderDropzone"]{
  background:var(--card) !important;
  border:2px dashed var(--ink-soft) !important;
  border-radius:10px !important;
}
[data-testid="stFileUploaderDropzone"]:hover{ border-color:var(--accent) !important; }

/* [FIX] Was `.tc-card` on a raw HTML div from st.markdown() — that div
   never actually contained the real widgets after it (Streamlit renders
   subsequent st.* calls as SIBLINGS, not children, of markdown-injected
   HTML). The visible symptom was an empty white rounded box floating
   above each section. Fixed by using st.container(border=True, key=...)
   instead, which is a real Streamlit layout primitive — its children
   genuinely nest inside it. Streamlit exposes it in the DOM with a
   `st-key-<key>` class we can style directly. */
.st-key-source_card, .st-key-fields_card {
  background:var(--card); border:1px solid var(--line); border-top:3px solid var(--ink);
  border-radius:10px; padding:22px 24px;
  box-shadow: 0 1px 2px rgba(27,42,74,0.06), 0 6px 16px rgba(27,42,74,0.07);
}
.tc-card-title{ font-family:'Space Grotesk',sans-serif; font-weight:600; font-size:15px; margin-bottom:14px; color:var(--ink); }

/* Quality tier badges — styled like a stamped document review mark */
.tc-badge{ display:inline-block; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:700; letter-spacing:0.04em; text-transform:uppercase; }
.tc-badge-green{ background:var(--green-soft); color:var(--green); border:1px solid var(--green); }
.tc-badge-amber{ background:var(--amber-soft); color:var(--amber); border:1px solid var(--amber); }
.tc-badge-red{ background:var(--red-soft); color:var(--red); border:1px solid var(--red); }

/* Corrected-field indicator — echoes construction redline markup */
.tc-redline-label{ color:var(--accent); font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em; }

.tc-mono{ font-family:'JetBrains Mono','Courier New',monospace; font-size:13px; background:#F4F2EC; padding:14px 16px; border-radius:8px; border:1px solid var(--line); max-height:420px; overflow-y:auto; white-space:pre-wrap; line-height:1.55; }

div.stButton > button{ background:var(--accent); color:white; border:none; border-radius:8px; font-weight:600; padding:0.55em 1.4em; }
div.stButton > button:hover{ background:#D0501C; color:white; }
div.stButton > button:disabled{ background:#D8D4C8; color:#8A8677; }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────
# Session state initialisation — THE STATE-LOCKING MECHANISM
# ──────────────────────────────────────────────────────────────────────────
#
# Streamlit reruns this entire script top-to-bottom on every widget
# interaction. Without session_state, every rerun would reset every
# variable to a fresh default — a spam-click on "Process" would kick
# off N overlapping OCR calls, and a page render would fight itself.
# session_state persists across reruns FOR THIS BROWSER TAB ONLY (it's
# scoped per session, not global), which is exactly the "state-locking"
# behaviour the spec asks for: it's what lets us say "already
# processing, ignore this click" instead of starting a second job.
#
def init_state():
    defaults = {
        "session_id": str(uuid.uuid4()),   # one stable ID per browser session
        "is_processing": False,             # THE race-condition guard
        "last_result": None,                # OCRResponse from the last successful run
        "last_error": None,
        "history": [],                      # every OCRResponse this session, newest first
        "pending_corrections": {},           # field -> corrected value, before submit
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val

init_state()


# ──────────────────────────────────────────────────────────────────────────
# Header
# ──────────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="tc-header">
  <div class="tc-eyebrow">TraceConnect · Alpha Prototype</div>
  <div class="tc-title">Document Intelligence Console</div>
  <div class="tc-sub">Upload a construction document. Review what the engine read. Correct what it missed.</div>
</div>
""", unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────────
# Sidebar — session info + storage stats (read-only, via the vault's own
# stats function so this file still never opens ocr_storage.json itself)
# ──────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("**Session**")
    st.caption(f"`{st.session_state.session_id[:8]}…`")
    st.markdown("**Documents this session**")
    st.markdown(f"### {len(st.session_state.history)}")

    st.divider()
    try:
        import data_vault as _dv_readonly_stats  # sidebar-only, read-only stats peek
        stats = _dv_readonly_stats.get_storage_stats()
        st.caption("All-time (all sessions)")
        st.markdown(f"📄 **{stats['total_documents_logged']}** documents logged")
        st.markdown(f"✏️ **{stats['total_corrections_logged']}** corrections logged")
    except Exception:
        pass

    st.divider()
    if st.session_state.history:
        st.markdown("**History**")
        for h in st.session_state.history[:8]:
            tier_dot = {"green": "🟢", "amber": "🟡", "red": "🔴"}.get(h.quality_tier, "⚪")
            st.caption(f"{tier_dot} {h.file_name}")


# ──────────────────────────────────────────────────────────────────────────
# Upload + dispatch
# ──────────────────────────────────────────────────────────────────────────
left, right = st.columns([1, 1], gap="large")

with left:
    with st.container(border=True, key="source_card"):
        st.markdown('<div class="tc-card-title">Source Document</div>', unsafe_allow_html=True)

        uploaded = st.file_uploader(
            "Drop a PDF, photo, or scan",
            type=["pdf", "png", "jpg", "jpeg", "heic", "heif", "tiff", "bmp"],
            disabled=st.session_state.is_processing,
            label_visibility="collapsed",
        )

        if uploaded is not None:
            if uploaded.type == "application/pdf":
                st.caption(f"📄 {uploaded.name} · {uploaded.size/1024:.1f} KB")
            else:
                st.image(uploaded, use_container_width=True)

        process_clicked = st.button(
            "🔍 Process Document",
            disabled=st.session_state.is_processing or uploaded is None,
            use_container_width=True,
        )

# ── The actual dispatch — guarded so a spam-click can't double-fire ──────
if process_clicked and uploaded is not None and not st.session_state.is_processing:
    st.session_state.is_processing = True
    file_bytes = uploaded.getvalue()
    file_name = uploaded.name

    with st.spinner(f"Running OCR on {file_name} — this can take a few seconds "
                     f"(longer on first run while models warm up)…"):
        try:
            response = engine_bridge.run_async(
                engine_bridge.dispatch_ocr(file_name, file_bytes, st.session_state.session_id)
            )
        except Exception as e:
            # Absolute last-resort catch — dispatch_ocr already guarantees it
            # never raises, but a UI must never trust "never" from any layer.
            response = None
            st.session_state.last_error = f"Unexpected failure: {type(e).__name__}: {e}"

    st.session_state.is_processing = False

    if response is not None:
        if response.ok:
            st.session_state.last_result = response
            st.session_state.last_error = None
            st.session_state.history.insert(0, response)
            st.session_state.pending_corrections = {}
        else:
            st.session_state.last_error = response.error_message
            st.session_state.last_result = None

    st.rerun()   # clean re-render from the new state, rather than falling through


# ──────────────────────────────────────────────────────────────────────────
# Right column — parsed fields + correction form
# ──────────────────────────────────────────────────────────────────────────
with right:
    with st.container(border=True, key="fields_card"):
        st.markdown('<div class="tc-card-title">Parsed OCR Fields</div>', unsafe_allow_html=True)

        if st.session_state.last_error:
            st.error(f"⚠ {st.session_state.last_error}")

        result = st.session_state.last_result
        if result is None and not st.session_state.last_error:
            st.caption("Upload and process a document to see extracted fields here.")

        if result is not None:
            badge_class = f"tc-badge-{result.quality_tier}" if result.quality_tier else "tc-badge-amber"
            st.markdown(
                f'<span class="tc-badge {badge_class}">{result.quality_tier or "unknown"} '
                f'· {result.confidence_score:.2f}</span>'
                f'&nbsp;&nbsp;<span style="color:var(--ink-soft);font-size:13px;">'
                f'via {result.extraction_method} · {result.total_pages} page(s) · '
                f'{result.language_detected}</span>',
                unsafe_allow_html=True,
            )
            if result.quality_flags:
                st.caption("⚑ " + ", ".join(result.quality_flags))
            if result.quality_tier == "red" and result.extraction_fallbacks:
                st.warning("**Why this failed — each stage's actual error:**\n\n" +
                           "\n".join(f"- `{f}`" for f in result.extraction_fallbacks))

            st.markdown("<br>", unsafe_allow_html=True)

            # ── Correction form: pre-filled with auto-extracted values ──
            correctable_fields = {
                "canonical_document_type": result.canonical_document_type,
                "document_reference": result.document_reference,
                "revision_number": result.revision_number,
                "document_date": result.document_date,
            }
            with st.form(key=f"corrections_{result.document_id}"):
                st.markdown('<span class="tc-redline-label">Confirm or correct</span>',
                            unsafe_allow_html=True)
                corrected = {}
                for field, auto_val in correctable_fields.items():
                    label = field.replace("_", " ").title()
                    corrected[field] = st.text_input(
                        label, value=auto_val or "",
                        placeholder="(not detected — enter manually)",
                        key=f"input_{field}_{result.document_id}",
                    )
                feedback_rating = st.slider("How accurate was this extraction overall?",
                                             1, 5, 4, key=f"rating_{result.document_id}")
                submitted = st.form_submit_button("💾 Save Corrections", use_container_width=True)

            if submitted:
                saved_count = 0
                for field, new_val in corrected.items():
                    auto_val = correctable_fields[field]
                    ok = engine_bridge.run_async(
                        engine_bridge.dispatch_correction(
                            result.document_id, field, auto_val, new_val,
                            st.session_state.session_id,
                        )
                    )
                    if ok and str(new_val) != str(auto_val or ""):
                        saved_count += 1
                st.success(f"Saved. {saved_count} field(s) corrected — thanks, this "
                           f"directly trains the next version of the engine.")

            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown('<span class="tc-redline-label">Extracted text</span>', unsafe_allow_html=True)
            st.markdown(f'<div class="tc-mono">{result.markdown_text or "(no text extracted)"}</div>',
                        unsafe_allow_html=True)
