"""
engine_bridge.py — MID-END / MIDDLEWARE (DISPATCH & VALIDATION LAYER)
=======================================================================
This layer's entire job is to be the boring, strict, unglamorous
translator between "whatever the UI hands us" and "exactly what the
backend is allowed to receive." It never processes a document itself
(that's data_vault.py's job) and never renders anything (that's
app.py's job). If you're tempted to add a st.* call or an OCR call
here, it belongs in a different file.

WHY PYDANTIC:
Python is dynamically typed — nothing stops app.py from accidentally
passing a None where a filename string was expected, or a corrupted
dict where a full record was expected. Pydantic gives us a DATA
CONTRACT: a schema that's validated the instant data crosses this
boundary, with a clear, structured error if it doesn't match — instead
of a cryptic KeyError three function calls deep inside the OCR engine.
This is the same instinct behind API request/response schemas at any
company operating at scale (see the Scale AI deep-dive in the wiki).

WHY "ASYNC" HERE, GIVEN STREAMLIT ITSELF IS SYNCHRONOUS:
Streamlit reruns your whole script top-to-bottom on every interaction
— there's no persistent event loop the way there is in FastAPI. So
"async" here isn't giving you concurrent request handling the way it
would in a real async web server. What it DOES give you, honestly:
  1. A clean seam. dispatch_ocr() is already shaped exactly like a
     FastAPI route handler. When you outgrow Streamlit and move this
     app's logic behind a real API (per the Rev02 roadmap), this
     function moves over almost unchanged.
  2. Real thread offload. We run the actual OCR call in a worker
     thread via asyncio.to_thread(), so a slow OCR call doesn't block
     Streamlit's script execution any more than it has to, and we get
     a real timeout guard on top of it.
We call this out explicitly rather than pretend Streamlit has FastAPI's
concurrency model — overselling that would just teach you a wrong
mental model of how your own app works.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Any

from pydantic import BaseModel, Field, field_validator, ValidationError

import data_vault

log = logging.getLogger("engine_bridge")

SUPPORTED_SUFFIXES = {".pdf", ".png", ".jpg", ".jpeg", ".heic", ".heif", ".tiff", ".tif", ".bmp"}
MAX_FILE_SIZE_MB = 25
DISPATCH_TIMEOUT_S = 90     # generous ceiling; Docling model loading can be slow on first run


# ──────────────────────────────────────────────────────────────────────────
# Data contracts — the strict schema every request/response must satisfy
# ──────────────────────────────────────────────────────────────────────────

class OCRRequest(BaseModel):
    """What the frontend is allowed to ask for. Anything outside this
    shape is rejected before it ever reaches the OCR engine."""
    file_name: str
    file_bytes: bytes
    session_id: str = Field(..., min_length=1)

    @field_validator("file_name")
    @classmethod
    def suffix_must_be_supported(cls, v: str) -> str:
        suffix = Path(v).suffix.lower()
        if suffix not in SUPPORTED_SUFFIXES:
            raise ValueError(
                f"Unsupported file type '{suffix}'. Supported: {sorted(SUPPORTED_SUFFIXES)}"
            )
        return v

    @field_validator("file_bytes")
    @classmethod
    def size_must_be_reasonable(cls, v: bytes) -> bytes:
        size_mb = len(v) / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            raise ValueError(f"File is {size_mb:.1f}MB, exceeds {MAX_FILE_SIZE_MB}MB limit")
        if size_mb == 0:
            raise ValueError("File is empty")
        return v


class OCRResponse(BaseModel):
    """What the frontend is guaranteed to receive back — success or
    failure. app.py should never need to inspect a raw exception or a
    raw ocr_pipeline dict; it only ever sees this shape."""
    ok: bool
    document_id: Optional[str] = None
    file_name: str
    status: str                       # "ready" | "failed" | "rejected" | "error"
    extraction_method: Optional[str] = None
    confidence_score: Optional[float] = None
    quality_tier: Optional[str] = None
    quality_flags: list[str] = Field(default_factory=list)
    language_detected: Optional[str] = None
    markdown_text: str = ""
    total_pages: int = 0
    intents_detected: list[str] = Field(default_factory=list)
    was_normalised: bool = False
    canonical_document_type: Optional[str] = None
    document_reference: Optional[str] = None
    revision_number: Optional[str] = None
    document_date: Optional[str] = None
    error_message: Optional[str] = None
    session_id: str
    dispatched_at: str


class CorrectionRequest(BaseModel):
    document_id: str = Field(..., min_length=1)
    field_name: str = Field(..., min_length=1)
    auto_value: Any = None
    corrected_value: Any
    session_id: str = Field(..., min_length=1)


# ──────────────────────────────────────────────────────────────────────────
# Dispatch
# ──────────────────────────────────────────────────────────────────────────

async def dispatch_ocr(file_name: str, file_bytes: bytes, session_id: str) -> OCRResponse:
    """
    The single function app.py calls. Validates, dispatches to the
    backend off the main thread with a timeout, and ALWAYS returns a
    well-formed OCRResponse — never raises. This is the "catch errors
    before they propagate to the UI" requirement made concrete: a
    Streamlit app that lets a raw exception bubble up shows the user
    a red traceback and often loses their session state. This function
    guarantees that can't happen from anything inside the OCR path.
    """
    now = datetime.now(timezone.utc).isoformat()

    # 1. Validate the request shape before touching the backend at all
    try:
        request = OCRRequest(file_name=file_name, file_bytes=file_bytes, session_id=session_id)
    except ValidationError as e:
        log.warning(f"Request validation failed: {e}")
        return OCRResponse(ok=False, file_name=file_name, status="rejected",
                            error_message=_first_error_message(e),
                            session_id=session_id, dispatched_at=now)

    # 2. Dispatch to the backend in a worker thread, with a hard timeout
    try:
        raw_result = await asyncio.wait_for(
            asyncio.to_thread(data_vault.execute_ocr, request.file_bytes,
                               request.file_name, request.session_id),
            timeout=DISPATCH_TIMEOUT_S,
        )
    except asyncio.TimeoutError:
        log.error(f"OCR dispatch timed out after {DISPATCH_TIMEOUT_S}s: {file_name}")
        return OCRResponse(ok=False, file_name=file_name, status="error",
                            error_message=f"Processing timed out after {DISPATCH_TIMEOUT_S}s. "
                                          f"Try again — large files or a cold-start model "
                                          f"download can occasionally take longer than usual.",
                            session_id=session_id, dispatched_at=now)
    except Exception as e:
        log.exception(f"Unexpected dispatch failure: {file_name}")
        return OCRResponse(ok=False, file_name=file_name, status="error",
                            error_message=f"Internal error: {type(e).__name__}",
                            session_id=session_id, dispatched_at=now)

    # 3. Translate the backend's raw dict into the strict response contract
    if raw_result.get("vault_status") == "engine_error" or "error" in raw_result:
        return OCRResponse(ok=False, file_name=file_name, status="error",
                            error_message=raw_result.get("error", "Unknown engine error"),
                            session_id=session_id, dispatched_at=now)

    try:
        return OCRResponse(
            ok=True,
            document_id=raw_result.get("document_id"),
            file_name=file_name,
            status=raw_result.get("status", "ready"),
            extraction_method=raw_result.get("extraction_method"),
            confidence_score=raw_result.get("confidence_score"),
            quality_tier=raw_result.get("quality_tier"),
            quality_flags=raw_result.get("quality_flags", []),
            language_detected=raw_result.get("language_detected"),
            markdown_text=raw_result.get("markdown_text", ""),
            total_pages=raw_result.get("total_pages", 0),
            intents_detected=raw_result.get("intents_detected", []),
            was_normalised=raw_result.get("was_normalised", False),
            canonical_document_type=raw_result.get("canonical_document_type"),
            document_reference=raw_result.get("document_reference"),
            revision_number=raw_result.get("revision_number"),
            document_date=raw_result.get("document_date"),
            session_id=session_id,
            dispatched_at=now,
        )
    except ValidationError as e:
        # The engine returned something we didn't expect — a schema drift
        # bug, not a user-facing failure. Surface it honestly rather than
        # silently coercing bad data into a "successful" response.
        log.error(f"Backend result failed response contract: {e}")
        return OCRResponse(ok=False, file_name=file_name, status="error",
                            error_message="Internal data contract mismatch — check logs",
                            session_id=session_id, dispatched_at=now)


async def dispatch_correction(document_id: str, field_name: str, auto_value,
                               corrected_value, session_id: str) -> bool:
    try:
        req = CorrectionRequest(document_id=document_id, field_name=field_name,
                                 auto_value=auto_value, corrected_value=corrected_value,
                                 session_id=session_id)
    except ValidationError as e:
        log.warning(f"Correction validation failed: {e}")
        return False
    return await asyncio.to_thread(
        data_vault.log_correction, req.document_id, req.field_name,
        req.auto_value, req.corrected_value, req.session_id
    )


def _first_error_message(e: ValidationError) -> str:
    errors = e.errors()
    if not errors:
        return "Validation failed"
    return str(errors[0].get("msg", "Validation failed"))


def run_async(coro):
    """Small helper so app.py (fully synchronous) can call the async
    dispatch functions without every call site repeating asyncio
    boilerplate. Streamlit's script model has no running event loop of
    its own, so a fresh one per call is the correct, safe choice here."""
    return asyncio.run(coro)
