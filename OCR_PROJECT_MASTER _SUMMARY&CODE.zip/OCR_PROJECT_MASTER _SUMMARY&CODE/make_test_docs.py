"""
Generates synthetic construction documents to smoke-test the OCR pipeline
while we wait on real files from the partner. Mimics realistic structure:
mixed English/BM, construction refs, revision numbers, BM date formats.
"""
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path

OUT = Path("test_docs")
OUT.mkdir(exist_ok=True)

# ── Doc 1: Architect Instruction (native PDF, 2 pages) ──────────────────────
def make_ai_pdf():
    path = OUT / "ai_017_rev_c.pdf"
    c = canvas.Canvas(str(path), pagesize=A4)
    w, h = A4

    # Page 1
    c.setFont("Helvetica-Bold", 14)
    c.drawString(20*mm, h-25*mm, "ARCHITECT INSTRUCTION")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20*mm, h-33*mm, "AI-017  Rev C")
    c.setFont("Helvetica", 10)
    lines = [
        "Project: Menara Pelangi Commercial Tower, Petaling Jaya",
        "Date: 14 Ogos 2026",
        "To: Main Contractor - Jaya Bina Sdn Bhd",
        "From: Architect - DesignWorks Consultants",
        "",
        "Reference: RFI-023, Drawing A-201 Rev B",
        "",
        "Instruction:",
        "The contractor shall revise the beam schedule for Level 11 to Level 14",
        "in accordance with the structural engineer's approved concrete design.",
        "Contractor is instructed to submit within 7 working days a resubmission",
        "of Drawing A-201 reflecting the revised column and slab levels.",
        "",
        "Kelulusan jurutera struktur diperlukan sebelum kerja konkrit boleh diteruskan.",
        "Arkitek confirmed that the revision approved on site meeting 12 Ogos 2026.",
        "",
        "This instruction supersedes AI-017 Rev B dated 20/07/2026.",
    ]
    y = h - 45*mm
    for ln in lines:
        c.drawString(20*mm, y, ln)
        y -= 6*mm
    c.showPage()

    # Page 2
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20*mm, h-25*mm, "Site Meeting Minutes Extract - Item 4.6")
    c.setFont("Helvetica", 10)
    lines2 = [
        "Attendees: PM, QS, Site Supervisor, M&E Engineer",
        "Meeting Date: 12 Ogos 2026",
        "",
        "Item 4.6 - Beam Schedule Revision (Level 11-14)",
        "Discussion: contractor raised concern regarding clash between beam B-114",
        "and M&E ducting at Level 12. Structural engineer to review and confirm.",
        "",
        "Decision: Approved to proceed with revised beam schedule subject to",
        "architect instruction. Action required from contractor within 7 days.",
        "",
        "Action Owner: Ahmad (Site Supervisor)",
        "Due Date: 21 Ogos 2026",
        "Status: Open",
    ]
    y = h - 40*mm
    for ln in lines2:
        c.drawString(20*mm, y, ln)
        y -= 6*mm
    c.save()
    return path

# ── Doc 2: RFI (native PDF, 1 page, English-heavy) ──────────────────────────
def make_rfi_pdf():
    path = OUT / "rfi_023.pdf"
    c = canvas.Canvas(str(path), pagesize=A4)
    w, h = A4
    c.setFont("Helvetica-Bold", 14)
    c.drawString(20*mm, h-25*mm, "REQUEST FOR INFORMATION")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(20*mm, h-33*mm, "RFI-023")
    c.setFont("Helvetica", 10)
    lines = [
        "Project: Menara Pelangi Commercial Tower",
        "Date: 20/07/2026",
        "Raised by: Jaya Bina Sdn Bhd (Contractor)",
        "Addressed to: DesignWorks Consultants (Architect)",
        "",
        "Question: Please confirm the beam specification for Level 11-14 as",
        "drawing A-201 Rev B shows conflicting dimensions to the structural",
        "drawing S-114 Rev A. Contractor requires confirmation before",
        "proceeding with concrete pour scheduled for next week.",
        "",
        "Bro drawing tu dah rev C ke? Site team confuse sikit pasal beam level.",
        "",
        "Response required by: 27/07/2026",
        "Status: Awaiting Response",
    ]
    y = h - 45*mm
    for ln in lines:
        c.drawString(20*mm, y, ln)
        y -= 6*mm
    c.save()
    return path

# ── Doc 3: Site report photo (rendered as image -> forces Tesseract path) ──
def make_scanned_image():
    path = OUT / "site_report_photo.png"
    img = Image.new("RGB", (1600, 2000), color=(245, 245, 240))
    draw = ImageDraw.Draw(img)
    try:
        font_big = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 40)
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 28)
    except Exception:
        font_big = font = ImageFont.load_default()

    lines = [
        ("SITE DAILY REPORT", font_big),
        ("", font),
        ("Project: Menara Pelangi Commercial Tower", font),
        ("Date: 25 Ogos 2026", font),
        ("Weather: Sunny, hujan petang", font),
        ("", font),
        ("Progress: Level 11 column concrete pour completed.", font),
        ("NCR-004 raised for cover block spacing deviation.", font),
        ("Contractor instructed to rectify within 3 days.", font),
        ("Site supervisor: Ahmad", font),
        ("Approved by: Site Manager", font),
    ]
    y = 60
    for text, f in lines:
        draw.text((60, y), text, fill=(20, 20, 20), font=f)
        y += 70
    img.save(path, dpi=(150, 150))
    return path

if __name__ == "__main__":
    p1 = make_ai_pdf()
    p2 = make_rfi_pdf()
    p3 = make_scanned_image()
    print("Created:")
    for p in (p1, p2, p3):
        print(" -", p, f"({p.stat().st_size} bytes)")
