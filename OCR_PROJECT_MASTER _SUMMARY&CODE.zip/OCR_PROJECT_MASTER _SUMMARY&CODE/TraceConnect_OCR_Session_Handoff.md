# TraceConnect OCR Pipeline — Session Handoff
**Version:** v1.1.0 (Ref 0 Gap-Fixed)
**Date:** August 2026
**Repo:** BuildTrace-Labs/traceconnect
**Status:** Pre-MVP · Pipeline foundation built · Never run on real documents yet

---

## 1. Project Objective

TraceConnect OCR Pipeline is a local, licence-safe, multi-stage document ingestion engine that converts Malaysian construction documents (PDF, DOCX, XLSX, images, WhatsApp photos) into structured, provenance-tagged JSON — page by page — feeding a downstream evidence graph (PostgreSQL + pgvector) that powers an AI assistant with page-level citations.

The system is designed as a **data flywheel**: every document processed accumulates structured signals (intents, BM translations, human corrections, engine performance) that progressively improve classification accuracy without requiring model retraining from scratch.

---

## 2. Current System Specs

### Language & Runtime

| Item | Value |
|------|-------|
| Language | Python 3.9+ |
| Entry point | `ocr_pipeline.py` v1.1.0 (999 lines, 18 sections) |
| Companion module | `language_normaliser.py` v1.0.0 (auto-imported at runtime) |
| Token encoding | `cl100k_base` via tiktoken (same as Claude + GPT-4) |

### Extraction Libraries

| Stage | Library | Licence | Handles |
|-------|---------|---------|---------|
| S0 | `markitdown[all]` ≥0.1.6 (Microsoft) | MIT ✅ | PDF, DOCX, XLSX, PPTX, MSG, EML, HTML, CSV, TXT |
| S1 | `docling` ≥2.0.0 (IBM) | MIT ✅ | Complex PDF layouts, drawings, tables |
| S2 | `pytesseract` + Tesseract binary | Apache-2.0 ✅ | Scanned images, HEIC, low-quality |
| S2 helper | `pymupdf` (fitz) | **AGPL ⚠️** | PDF→image for Tesseract. Replace with `pdfplumber` (MIT) before production |
| S2 helper | `pillow-heif` | MIT ✅ | iPhone HEIC/HEIF format |

### Supporting Libraries

| Library | Purpose | Licence |
|---------|---------|---------|
| `tiktoken` | Token counting (cl100k_base) | MIT ✅ |
| `langdetect` | Language detection (seed=42, deterministic) | Apache-2.0 ✅ |
| `Pillow` | Image open/convert for Tesseract | MIT ✅ |
| `concurrent.futures` | Multiprocessing batch (stdlib) | — |

### Quality Thresholds (tunable constants)

| Constant | Value | Purpose |
|----------|-------|---------|
| `MIN_MARKDOWN_LENGTH` | 100 chars | Below this → score 0.0 immediately |
| `MIN_MARKITDOWN_SCORE` | 0.40 | Below → fall to Docling |
| `MIN_DOCLING_SCORE` | 0.35 | Below → fall to Tesseract |
| `GREEN_CONFIDENCE` | 0.85 | AI uses freely |
| `AMBER_CONFIDENCE` | 0.60 | AI uses with caveat |
| Red tier | < 0.60 | Quarantine — no AI access |

### Auto-generated Output Files

| File | Created by | Contents |
|------|-----------|---------|
| `ocr_outputs/{name}_ocr.json` | every run | Full structured output |
| `ocr_outputs/{name}_preview.txt` | every run | Human-readable summary |
| `ocr_outputs/fingerprint_registry.json` | [C1] | SHA-256 → cached result path |
| `ocr_outputs/failed_queue.json` | [C3] | Failed docs + stage errors + retry count |
| `ocr_outputs/performance_log.jsonl` | [M3] | One JSONL line per document, queryable with pandas |

---

## 3. Key Architectural Decisions & Rationale

- **Three-stage waterfall (S0→S1→S2), not parallel** — Fastest engine first. Only escalate when quality gate fails. Saves compute. Order: MarkItDown → Docling → Tesseract.
- **Quality gate score-based not binary** — `score_markdown_quality()` returns 0.0–1.0. Enables Amber tier (AI with caveat) vs forced binary pass/fail.
- **Construction keyword bonus (+0.20/+0.10)** — Rewards domain-relevant content over raw character length. A garbled scan cannot fake its way to Amber.
- **Base quality score 0.30 not 0.50** — Original 0.50 was too generous. Now a document needs actual construction keywords to reach Amber tier.
- **SHA-256 fingerprint registry** — Prevents duplicate processing. Same file from email and WhatsApp → one OCR run, one cached result, instant return on repeat.
- **Per-page split via PyMuPDF** — Page-level provenance is non-negotiable for the evidence chain. `pages[]` array in every JSON enables AI to cite "AI-017 Rev C, Page 3" with integrity.
- **pillow-heif registered at import time** — Malaysian site workers use iPhones. HEIC is default camera format. Registering at startup means `Image.open()` handles HEIC transparently.
- **Language normaliser imported at runtime not module level** — Graceful degradation. If `language_normaliser.py` is absent, pipeline continues. Intents and BM counts default to empty dicts.
- **Multiprocessing via `ProcessPoolExecutor`** — Sequential for loop was O(n) wall time. `_worker()` is top-level (required for pickling). Default 4 workers, configurable via `--workers`.
- **`human_corrections` template in every JSON** — Four fields (doc type, revision, date, doc reference) each with `auto_extracted`, `human_corrected`, `corrected_by`, `corrected_at`. Every UI correction is one labelled training example.
- **`performance_log.jsonl` append-only** — One line per document. Never overwrites. Query: `pd.read_json('performance_log.jsonl', lines=True)`. Enables real-data threshold calibration.
- **AGPL flag on PyMuPDF** — Flagged in docstring and comments. Must be replaced with `pdfplumber` (MIT) before any commercial deployment.
- **BM month normalisation via regex + dict** — `"14 Ogos 2026"` → `"2026-08-14"`. Covers 12 BM month names including colloquial forms (`ogo`, `ogos`, `dis`).
- **DetectorFactory seed=42** — Deterministic language detection. Without seed, `langdetect` is non-deterministic on short texts.
- **Three-section language sampling (start + middle + end)** — Previous first-2000-char approach misclassified long BM contracts with English cover pages as `"en"`.
- **Docling quality gate added at 0.35** — Previously Docling had no threshold. Garbled Docling output was silently accepted. Now falls through to Tesseract if score < 0.35.
- **`compression_pct` clamped to 0.0 minimum** — Enhancement adds backtick/bold markers which can make output marginally longer than raw. Without clamping, negative compression confused analytics. `was_expanded` flag added.

---

## 4. Gap Fix Log (v1.0.0 → v1.1.0)

### Critical (4)

| Ref | Fix | Before | After |
|-----|-----|--------|-------|
| C1 | Fingerprint registry | Fingerprint computed, never checked | SHA-256 checked against registry before OCR. Duplicate returns cached result instantly |
| C2 | Per-page output | Entire doc as one text blob | `pages[]` array in every JSON. Each entry: `page_number`, `raw_text`, `markdown_text`, `token_count`, `confidence_score`, `is_empty` |
| C3 | Failed queue | Failed docs logged but lost | Saved to `failed_queue.json` with `stage_errors` and `retry_count`. `--retry-failed` flag reprocesses |
| C4 | HEIC support | `.heic` / `.heif` silently rejected | Added to `SUPPORTED_TYPES`. `pillow-heif` registered at startup. iPhone photos now work |

### High (6)

| Ref | Fix | Before | After |
|-----|-----|--------|-------|
| H1 | Quality scorer | Base score 0.50, structure-only | Base 0.30, +0.20 for 2+ construction keywords, +0.10 for 5+ |
| H2 | BM month names | Only numeric dates handled | `"14 Ogos 2026"` → `"2026-08-14"`. All 12 BM months mapped |
| H3 | Docling quality gate | No threshold — garbled output accepted | Falls through if score < 0.35 |
| H4 | Normaliser connected | Two scripts with no data sharing | `run_language_normaliser()` called in `run_pipeline()`. Intents, BM terms, particles stored in output JSON |
| H5 | Batch multiprocessing | Sequential `for` loop | `ProcessPoolExecutor`, 4 workers default, `--workers N` flag |
| H6 | Language detection | First 2000 chars only | Samples start + middle + end. Mixed BM/English long docs now correctly detected |

### Medium (5)

| Ref | Fix | Before | After |
|-----|-----|--------|-------|
| M1 | Compression clamped | Could go negative | `max(0.0, ...)` applied. `was_expanded` bool added |
| M2 | Scan metadata | Nothing recorded for images | DPI, dimensions, contrast, aspect ratio, `likely_landscape` in output JSON |
| M3 | Performance log | No cross-document analytics | `performance_log.jsonl` — one line per doc, queryable |
| M4 | Ground truth validation | No accuracy measurement | `--validate test_docs/ ground_truth/` compares to `_expected.json` files, reports % accuracy |
| M5 | Feedback capture | No training data structure | `human_corrections` dict in every JSON. UI layer populates. Each correction = one training example |

---

## 5. Output JSON Schema

Every document processed produces this structure:

```json
{
  "document_id": "uuid-v4",
  "file_name": "ai_017_rev_c.pdf",
  "file_path": "test_docs/ai_017_rev_c.pdf",
  "file_type": "pdf",
  "file_size_kb": 142.3,
  "document_fingerprint": "sha256-hex",
  "source_origin": "manual_upload",
  "_from_cache": false,

  "extraction_method": "markitdown",
  "extraction_fallbacks": [],
  "processing_time_s": 1.4,
  "extraction_timestamp": "2026-08-30T08:00:00+00:00",

  "confidence_score": 0.87,
  "quality_tier": "green",
  "quality_flags": [],
  "markdown_quality": {
    "score": 0.87, "headings_count": 6, "tables_count": 1,
    "lists_count": 4, "char_count": 4820, "assessment": "excellent",
    "keyword_hits": 7, "garble_ratio": 0.041
  },
  "scan_metadata": {},

  "language_detected": "mixed",
  "markdown_text": "# ARCHITECT INSTRUCTION NO. `AI-017` `Rev C`...",
  "raw_text": "ARCHITECT INSTRUCTION NO. AI-017 Rev C...",

  "pages": [
    {
      "page_number": 1, "total_pages": 3,
      "raw_text": "ARCHITECT INSTRUCTION...",
      "markdown_text": "# ARCHITECT INSTRUCTION...",
      "token_count": 312,
      "confidence_score": 0.90,
      "is_empty": false
    }
  ],
  "total_pages": 3,

  "token_count": 2340,
  "raw_token_count": 9100,
  "compression_pct": 74.3,
  "was_expanded": false,

  "normalised_text": "The architect instructs the contractor to revise...",
  "language_profile": {"has_bahasa_malaysia": true, "has_manglish": false},
  "intents_detected": ["requesting_action"],
  "bm_translations_count": 2,
  "particles_found": [],
  "was_normalised": true,

  "status": "ready",

  "canonical_document_type": null,
  "document_reference": null,
  "revision_number": null,
  "document_date": null,
  "sender": null,
  "recipient": null,
  "is_superseded": false,
  "superseded_by": null,
  "thread_parent_id": null,

  "human_corrections": {
    "canonical_document_type": {
      "auto_extracted": null,
      "human_corrected": null,
      "corrected_by": null,
      "corrected_at": null
    },
    "revision_number": {"auto_extracted": null, "human_corrected": null, "corrected_by": null, "corrected_at": null},
    "document_date": {"auto_extracted": null, "human_corrected": null, "corrected_by": null, "corrected_at": null},
    "document_reference": {"auto_extracted": null, "human_corrected": null, "corrected_by": null, "corrected_at": null}
  }
}
```

---

## 6. CLI Reference

```bash
# Single file
python ocr_pipeline.py --file "rfi_023.pdf"

# Compare all 3 engines on same file
python ocr_pipeline.py --file "rfi_023.pdf" --compare

# Stats only — no file saved
python ocr_pipeline.py --file "rfi_023.pdf" --stats

# Batch — parallel, 4 workers default
python ocr_pipeline.py --folder "test_docs/"

# Batch — 8 workers
python ocr_pipeline.py --folder "test_docs/" --workers 8

# Retry all failed documents
python ocr_pipeline.py --retry-failed

# Validate against ground truth
python ocr_pipeline.py --validate test_docs/ test_docs/ground_truth/

# Test language normaliser standalone
python language_normaliser.py --test
python language_normaliser.py --text "Bro drawing tu dah rev C ke?"
```

---

## 7. Install Commands

```bash
# Full install
pip install markitdown[all] docling pytesseract pillow pymupdf
pip install tiktoken langdetect pillow-heif

# Tesseract binary (separate from pip)
brew install tesseract           # Mac
sudo apt install tesseract-ocr   # Linux
# Windows: https://github.com/UB-Mannheim/tesseract/wiki

# Verify
python ocr_pipeline.py --file "test_docs/rfi_023.pdf" --stats
```

---

## 8. Active Blockers & Backlog

### Immediate Blockers — Nothing Works Until These Are Done

| Priority | Item | Status |
|----------|------|--------|
| P0 | `pip install pillow-heif` — not yet in requirements.txt | ❌ Missing |
| P0 | Tesseract binary installation not confirmed | ❌ Unknown |
| P0 | `test_docs/` folder is empty — no real documents | ❌ Empty |
| P0 | Pipeline has never been run on real Malaysian construction documents | ❌ Never executed |

### Known Code Defect

| Location | Defect |
|----------|--------|
| `run_pipeline()` — output dict | `"document_id": document_id if False else doc_id` — dead code fragment. `document_id` is undefined. Evaluates correctly because `if False` always takes `doc_id` branch. Clean to: `"document_id": doc_id` |

### Backlog — Priority Order

| # | Item | Depends on | Effort |
|---|------|-----------|--------|
| 1 | **Run POC 1 benchmark** — 5 real docs, `--compare`, record results table | Test docs from partner | 1 day |
| 2 | **Build `text_processor.py`** — 70% token compression, semantic chunking, metadata extraction | POC 1 results | 2–3 days |
| 3 | **Create ground truth set** — 2–3 `_expected.json` in `test_docs/ground_truth/` | POC 1 run | 2–4 hours |
| 4 | **Run `--validate`** — establish first accuracy % baseline | Ground truth files | 30 min |
| 5 | **Update `requirements.txt`** — add `pillow-heif` | — | 5 min |
| 6 | **Fix dead code** in `run_pipeline()` output dict | — | 2 min |
| 7 | **Build `document_identity.py`** — doc type classifier, reference extractor | text_processor.py | 1–2 days |
| 8 | **Build `event_logger.py`** — append-only audit trail | document_identity.py | 1 day |
| 9 | **Replace PyMuPDF with `pdfplumber`** — AGPL → MIT before commercial deployment | After POC 1 | 2–4 hours |
| 10 | **Talk to 10 construction professionals** — validate product-market fit | — | This week |

### Pipeline Downstream (Not Started)

| Module | Status | Description |
|--------|--------|-------------|
| `text_processor.py` | Prompt ready, not built | 70% token compression, 150–300 token semantic chunks |
| `document_identity.py` | Planned | Intake dedup, construction taxonomy classifier |
| `event_logger.py` | Planned | Append-only PostgreSQL `document_events` table |
| FastAPI backend | Planned | Sprint 1 — project creation, upload, processing status |
| Next.js frontend | Planned | Sprint 1 — document register, upload zone, revision badges |
| pgvector embeddings | Planned | Sprint 2 — after chunks in PostgreSQL |
| Jarvis AI assistant | Planned | Sprint 4 — after retrieval pipeline stable |

---

## 9. Data Flywheel Plan

| Phase | Volume | What You Learn |
|-------|--------|----------------|
| Ref 0 (Now) | 5 test docs | Which engine wins per doc type. First ground truth baseline. |
| First Pilot | 100–500 docs | Real BM/Manglish patterns. OCR confidence by doc type. Threshold tuning from data. |
| Scale | 500–5,000 | Engine selection model. Dispute prediction patterns. Intent trends per project. |
| Fine-tune | 5,000–10,000 | Custom doc type classifier. Custom NER for construction refs. Custom embeddings. |
| Visionary | 10,000+ | Largest labelled Malaysian construction dataset. Defensible moat. |

### What Is Captured Automatically (every run)
- Extraction method winner per document → `performance_log.jsonl`
- Quality score per engine → threshold calibration
- BM terms translated + particles found → dictionary expansion signal
- Intents detected → intent classifier training signal
- Scan quality metadata (DPI, contrast) → pre-processing improvement signal
- Fallback reasons → most common failure modes

### What Needs Human Action (training data)
- Doc type correction in UI → `human_corrections.canonical_document_type`
- Revision number correction → `human_corrections.revision_number`
- Date correction → `human_corrections.document_date`
- Doc reference correction → `human_corrections.document_reference`

---

## 10. File Inventory

| File | Version | Status | Description |
|------|---------|--------|-------------|
| `ocr_pipeline.py` | v1.1.0 | ✅ BUILT | Main pipeline — all 15 gaps fixed |
| `ocr_pipeline_ref0_backup.py` | v1.0.0 | ✅ BACKUP | Original before gap fixes |
| `language_normaliser.py` | v1.0.0 | ✅ BUILT | Auto-called by pipeline. 120+ BM terms, 8 intents |
| `requirements.txt` | — | ⚠️ UPDATE | Add `pillow-heif` |
| `CONTEXT.md` | — | ⚠️ UPDATE | Update to reflect v1.1.0 complete |
| `pipeline_monitor.jsx` | v1.0 | ✅ BUILT | React real-time node graph dashboard |
| `text_processor.py` | — | ⏳ NEXT | Prompt ready. Build after POC 1. |
| `document_identity.py` | — | 📋 PLANNED | Doc type classifier |
| `event_logger.py` | — | 📋 PLANNED | Append-only audit trail |

---

## 11. Licence Safety Register

| Tool | Licence | Status | Note |
|------|---------|--------|------|
| MarkItDown (Microsoft) | MIT | ✅ SAFE | Approved for commercial use |
| Docling (IBM) | MIT | ✅ SAFE | Model licences need separate audit |
| Tesseract | Apache-2.0 | ✅ SAFE | Approved |
| tiktoken | MIT | ✅ SAFE | Token counting only |
| langdetect | Apache-2.0 | ✅ SAFE | Approved |
| pillow-heif | MIT | ✅ SAFE | Approved |
| Pillow | MIT | ✅ SAFE | Approved |
| PyMuPDF (fitz) | **AGPL-3.0** | ⚠️ REVIEW | Replace with `pdfplumber` (MIT) before production |
| OpenConstructionERP | AGPL-3.0 | ❌ STUDY ONLY | Design reference only. Never use code. |

---

## 12. Next Session — Start Here

```bash
# Step 1 — Install new dependency
pip install pillow-heif

# Step 2 — Install Tesseract binary if not done
brew install tesseract   # Mac

# Step 3 — Get 5 real PDFs from partner, put in test_docs/
# Types: drawing, RFI, Architect Instruction, meeting minutes, site photo

# Step 4 — Run pipeline on all 5
python ocr_pipeline.py --folder "test_docs/"

# Step 5 — Compare engines on one file
python ocr_pipeline.py --file "test_docs/rfi_023.pdf" --compare

# Step 6 — Test language normaliser
python language_normaliser.py --test

# Step 7 — Create ground truth and validate
mkdir test_docs/ground_truth
# Create rfi_023_expected.json (see schema in section 8)
python ocr_pipeline.py --validate test_docs/ test_docs/ground_truth/

# Step 8 — Share benchmark results with partner (POC 1 complete)
```

---

*TraceConnect — Connect Documents. Trace Decisions. Resolve Issues.*
*Ref 0 · August 2026 · BuildTrace-Labs/traceconnect*
